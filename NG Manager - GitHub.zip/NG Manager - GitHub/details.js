// Function to display extension details
const showExtensionDetails = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const extensionId = urlParams.get('id');

    if (!extensionId) {
        showError('No extension ID was provided in the URL. Please ensure the URL contains a valid extension ID.');
        return;
    }

    chrome.management.get(extensionId, (extension) => {
        const extensionDetails = document.getElementById('extension-details');
        if (!extensionDetails) {
            showError('The extension details container is missing in the HTML.');
            return;
        }
        extensionDetails.innerHTML = '';

        if (chrome.runtime.lastError) {
            showError(`An error occurred while retrieving extension details. Error: ${chrome.runtime.lastError.message}`);
            return;
        }

        if (!extension) {
            showError('No extension found with the provided ID. The extension might be uninstalled or the ID may be incorrect.');
            return;
        }

        // Extension Information
        extensionDetails.appendChild(createElement('h2', { textContent: extension.name, className: 'gradient-text' }));
        extensionDetails.appendChild(createElement('p', {
            innerHTML: `<i class="material-icons">info</i> Version: ${extension.version} (ID: ${extension.id})${extension.manifestVersion ? ` - Manifest v${extension.manifestVersion}` : ''}`
        }));
        extensionDetails.appendChild(createElement('p', { innerHTML: `<i class="material-icons">description</i> Description: ${extension.description}` }));

        if (extension.creator) {
            extensionDetails.appendChild(createElement('p', { innerHTML: `<i class="material-icons">person</i> Creator: ${extension.creator}` }));
        }

        if (extension.homepageUrl) {
            extensionDetails.appendChild(createElement('p', {
                innerHTML: `<i class="material-icons">link</i> Homepage: <a href="${extension.homepageUrl}" target="_blank">${extension.homepageUrl}</a>`
            }));
        }

        if (extension.optionsUrl) {
            extensionDetails.appendChild(createElement('p', {
                innerHTML: `<i class="material-icons">settings</i> Options: <a href="${extension.optionsUrl}" target="_blank">Open Options</a>`
            }));
        }

        extensionDetails.appendChild(createElement('p', {
            id: 'enabled-status',
            innerHTML: `<i class="material-icons">power_settings_new</i> Status: ${extension.enabled ? 'Enabled' : 'Disabled'}`
        }));

        // Action Buttons
        const currentExtensionId = 'ninhjdeipacebhgbhblhjglnaajfehio'; // Current extension manager's ID

        if (extension.id !== currentExtensionId) {
            const buttonContainer = createElement('div', { className: 'button-container' });

            const enableDisableButton = createElement('button', {
                id: 'enable-disable-btn',
                textContent: extension.enabled ? 'Disable' : 'Enable',
                onclick: () => toggleExtensionStatus(extensionId, !extension.enabled)
            });
            buttonContainer.appendChild(enableDisableButton);

            const uninstallButton = createElement('button', {
                id: 'uninstall-btn',
                textContent: 'Uninstall',
                onclick: () => uninstallExtension(extensionId)
            });
            buttonContainer.appendChild(uninstallButton);

            extensionDetails.appendChild(buttonContainer);
        }

        // Permissions Section
        const permissionsBox = createPermissionsSection(extension.permissions || []);
        extensionDetails.appendChild(permissionsBox);

        // Initialize Permissions UI
        initializePermissionsUI();
    });
};

// Utility function to create elements with attributes
const createElement = (tag, attributes = {}) => {
    const element = document.createElement(tag);
    Object.keys(attributes).forEach(attr => {
        if (attr === 'style') {
            Object.assign(element.style, attributes[attr]);
        } else if (attr.startsWith('on') && typeof attributes[attr] === 'function') {
            element.addEventListener(attr.substring(2), attributes[attr]);
        } else {
            element[attr] = attributes[attr];
        }
    });
    return element;
};

// Function to create the permissions section with explanations
const createPermissionsSection = (extensionPermissions) => {
    const permissionsBox = createElement('div', { className: 'permissions-box' });
    permissionsBox.appendChild(createElement('h3', { innerHTML: '<i class="material-icons">security</i> Permissions:' }));

    const permissionsGrid = createElement('div', { className: 'permissions-grid' });

    const permissionDescriptions = getPermissionDescriptions();

    const uniquePermissions = [...new Set(extensionPermissions)];

    if (uniquePermissions.length === 0) {
        permissionsBox.appendChild(createElement('p', {
            className: 'info-message',
            innerHTML: '<i class="material-icons">info</i> No permissions found for this extension. It may have no active permissions or there could be an issue with the permissions data.'
        }));
        return permissionsBox;
    }

    uniquePermissions.forEach(permission => {
        const description = permissionDescriptions[permission] || 'No description available for this permission.';
        const permissionItem = createElement('div', { className: 'permission-item' });
        permissionItem.appendChild(createElement('h4', { textContent: permission }));
        permissionItem.appendChild(createElement('p', { textContent: description }));
        permissionsGrid.appendChild(permissionItem);
    });

    permissionsBox.appendChild(permissionsGrid);
    return permissionsBox;
};

// Function to provide descriptions for each permission
const getPermissionDescriptions = () => {
    return {
        activeTab: 'Allows the extension to access the currently active tab when the user interacts with the extension.',
        contextMenus: 'Enables the extension to add items to the browser\'s context menu.',
        tabs: 'Grants access to the browser\'s tab system, allowing the extension to interact with browser tabs.',
        webNavigation: 'Allows the extension to observe and analyze navigation events in the browser.',
        webRequest: 'Enables the extension to observe and analyze traffic and to intercept, block, or modify requests in-flight.',
        webRequestBlocking: 'Allows the extension to block or modify network requests before they are sent.',
        notifications: 'Grants the ability to create and manage desktop notifications.',
        browsingData: 'Allows the extension to remove browsing data from a user\'s browser.',
        bookmarks: 'Enables the extension to interact with the user\'s bookmarks.',
        clipboardRead: 'Grants the ability to read data from the clipboard.',
        clipboardWrite: 'Allows the extension to write data to the clipboard.',
        downloads: 'Enables the extension to download files to the user\'s computer.',
        storage: 'Provides access to the browser\'s storage system, allowing the extension to store and retrieve data.',
        sessions: 'Allows the extension to retrieve information about the user\'s browsing sessions.',
        topSites: 'Grants access to the user\'s most visited sites.',
        tabCapture: 'Allows the extension to capture the visible area of a tab as a media stream.',
        contentSettings: 'Enables the extension to change or query settings for websites.',
        management: 'Grants the ability to manage other extensions, including installing, uninstalling, and disabling them.',
        history: 'Provides access to the user\'s browsing history.',
        power: 'Allows the extension to keep the computer awake.',
        idle: 'Enables the extension to detect when the user is idle.',
        system_cpu: 'Grants access to system CPU information.',
        system_memory: 'Provides information about the system\'s memory.',
        system_storage: 'Enables the extension to access system storage details.',
        dns: 'Allows the extension to manage DNS settings.',
        'udp-send': 'Grants the ability to send UDP packets.',
        'udp-receive': 'Enables the extension to receive UDP packets.',
        'tcp-connect': 'Allows the extension to initiate TCP connections.',
        proxy: 'Grants the ability to control the browser\'s proxy settings.',
        runtime: 'Provides access to the runtime environment, including messaging and extension lifecycle events.',
        alarms: 'Enables the extension to schedule code to run periodically.',
        nativeMessaging: 'Allows the extension to communicate with native applications installed on the user\'s computer.',
        gcm: 'Enables the extension to use Google Cloud Messaging for push notifications.',
        webSocket: 'Grants the ability to use WebSockets for real-time communication.',
        'networking.onc': 'Provides access to networking configurations.',
        geolocation: 'Allows the extension to access the user\'s geographical location.',
        identity: 'Grants the ability to manage user identity and authentication.',
        privacy: 'Enables the extension to control aspects of user privacy settings.',
        scripting: 'Provides the ability to inject and execute scripts in web pages.',
        declarativeContent: 'Allows the extension to define rules for modifying web pages based on specific conditions.',
        'tabs.executeScript': 'Grants the ability to execute scripts within the context of web pages.',
        'tabs.insertCSS': 'Enables the extension to inject CSS into web pages.',
        experimental: 'Provides access to experimental APIs that are not yet standardized.',
        debugger: 'Grants the ability to debug other extensions or web pages.',
        fileSystem: 'Allows the extension to access the user\'s file system.',
        unlimitedStorage: 'Provides the extension with unlimited storage space.',
        videoCapture: 'Enables the extension to capture video from the user\'s camera.',
        audioCapture: 'Grants the ability to capture audio from the user\'s microphone.',
        accessibilityFeatures: 'Allows the extension to read and modify accessibility features.'
        // Add more permissions and their descriptions as needed
    };
};

// Function to initialize permissions UI (expand/collapse)
const initializePermissionsUI = () => {
    document.querySelectorAll('.permission-group-header').forEach(header => {
        header.addEventListener('click', () => {
            const groupList = header.nextElementSibling;
            const isVisible = groupList.style.display === 'block';
            groupList.style.display = isVisible ? 'none' : 'block';
            header.querySelector('.material-icons').textContent = isVisible ? 'expand_more' : 'expand_less';
        });
    });
};

// Function to toggle extension status (enable/disable)
const toggleExtensionStatus = (extensionId, enable) => {
    chrome.management.setEnabled(extensionId, enable, () => {
        if (chrome.runtime.lastError) {
            showError(`An error occurred while toggling extension status. Error: ${chrome.runtime.lastError.message}`);
            return;
        }

        // Update status display and button text
        const statusElement = document.getElementById('enabled-status');
        const buttonElement = document.getElementById('enable-disable-btn');
        if (statusElement) {
            statusElement.innerHTML = `<i class="material-icons">power_settings_new</i> Status: ${enable ? 'Enabled' : 'Disabled'}`;
        }
        if (buttonElement) {
            buttonElement.textContent = enable ? 'Disable' : 'Enable';
        }
        showMessage(`Extension has been ${enable ? 'enabled' : 'disabled'}.`, 'success');
    });
};

// Function to uninstall the extension
const uninstallExtension = (extensionId) => {
    if (confirm('Are you sure you want to uninstall this extension?')) {
        chrome.management.uninstall(extensionId, () => {
            if (chrome.runtime.lastError) {
                showError(`An error occurred while uninstalling the extension. Error: ${chrome.runtime.lastError.message}`);
                return;
            }

            showMessage('Extension has been successfully uninstalled.', 'success');
            const extensionDetails = document.getElementById('extension-details');
            if (extensionDetails) {
                extensionDetails.innerHTML = '';
            }
        });
    }
};

// Function to display messages
const showMessage = (message, type) => {
    const extensionDetails = document.getElementById('extension-details');
    if (!extensionDetails) {
        console.error('The extension details container is missing in the HTML.');
        return;
    }

    const messageDiv = createElement('div', {
        textContent: message,
        style: {
            padding: '10px',
            margin: '10px 0',
            borderRadius: '5px',
            color: type === 'error' ? '#721c24' : '#155724',
            backgroundColor: type === 'error' ? '#f8d7da' : '#d4edda',
            border: type === 'error' ? '1px solid #f5c6cb' : '1px solid #c3e6cb'
        }
    });

    extensionDetails.insertBefore(messageDiv, extensionDetails.firstChild);
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
};

// Function to display an error message with detailed information
const showError = (message) => {
    showMessage(message, 'error');
};

document.addEventListener('DOMContentLoaded', showExtensionDetails);
