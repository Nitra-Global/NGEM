// content.js

function copyToClipboard(text) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
}

// Hört auf Nachrichten von background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'copy_url') {
    copyToClipboard(request.url);
    sendResponse({status: 'success'});
  }
});
