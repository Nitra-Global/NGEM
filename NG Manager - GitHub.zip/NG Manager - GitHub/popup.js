// Function to display installed extensions
function displayExtensions() {
  chrome.management.getAll(function(extensions) {
    
    var extensionList = document.getElementById('extension-list');
    extensionList.innerHTML = ''; // Clear previous list
    
    extensions.forEach(function(extension) {
      // Skip the "NG Extension Manager" extension
      if (extension.id === 'ninhjdeipacebhgbhblhjglnaajfehio') {
        return;
      }

      // Create container for each extension
      var extensionItem = document.createElement('div');
      extensionItem.classList.add('extension-item');
      
      // Extension Icon
      var icon = document.createElement('img');
      icon.src = extension.icons ? extension.icons[0].url : 'icons/128x128.png'; // Default icon if not available
      icon.alt = extension.name;
      icon.classList.add('extension-icon');
      
      // Extension Name
      var devBadge = document.createElement('div');
      devBadge.classList.add('dev-badge');
      
      var name = document.createElement('span');
      name.textContent = truncate(extension.name, 25); // Truncate long names
      name.classList.add('extension-name');
      
      devBadge.appendChild(name);

      // Extension Type
    var type = document.createElement('span');
    type.textContent = extension.type;
    type.classList.add('extension-type');
    type.style.display = 'none'; // Hide type for now

      // Enable/Disable Button
      var enableDisableButton = document.createElement('button');
      enableDisableButton.textContent = extension.enabled ? 'Disable' : 'Enable';
      enableDisableButton.classList.add('toggle-button');
      enableDisableButton.addEventListener('click', function() {
        chrome.management.setEnabled(extension.id, !extension.enabled, function() {
          displayExtensions(); // Refresh extension list after toggling
        });
      });

      // Open Button (only if it's an app)
      if (extension.type === 'hosted_app' || extension.type === 'packaged_app' || extension.type === 'legacy_packaged_app') {
        var openButton = document.createElement('button');
        openButton.textContent = 'Open';
        openButton.classList.add('open-button');
        openButton.addEventListener('click', function() {
          chrome.management.launchApp(extension.id);
        });
        extensionItem.appendChild(openButton); // Add the open button
      }

      // Details Button
      var detailsButton = document.createElement('button');
      detailsButton.textContent = 'Details';
      detailsButton.classList.add('details-button');
      detailsButton.addEventListener('click', function() {
        showExtensionDetails(extension);
      });

      // Delete Button
      var deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.classList.add('delete-button');
      deleteButton.addEventListener('click', function() {
        if (confirm('Are you sure you want to delete this extension?')) {
          chrome.management.uninstall(extension.id, function() {
            displayExtensions(); // Refresh extension list after uninstalling
          });
        }
      });
      
      // Append elements to extension item
      extensionItem.appendChild(icon);
      extensionItem.appendChild(name);
      extensionItem.appendChild(type);
      extensionItem.appendChild(enableDisableButton);
      extensionItem.appendChild(detailsButton);
      extensionItem.appendChild(deleteButton); // Add the delete button
      extensionList.appendChild(extensionItem);
    });
  });
}
  
// Function to truncate long extension names
function truncate(text, maxLength) {
  return text.length > maxLength ? text.substring(0, maxLength - 3) + '...' : text;
}

// Function to show extension details in a new tab
function showExtensionDetails(extension) {
  chrome.tabs.create({ url: 'details.html?id=' + extension.id });
}

// Function to initialize the extension manager popup
function initializePopup() {
  displayExtensions(); // Display installed extensions
  
  // Hide/Show Button
  var hideShowButton = document.getElementById('hide-show-button');
  var hidden = false;
  hideShowButton.addEventListener('click', function() {
    hidden = !hidden;
    var extensionItems = document.querySelectorAll('.extension-item');
    if (hidden) {
      hideShowButton.textContent = 'Show Disabled';
      extensionItems.forEach(function(item) {
        if (!item.querySelector('.toggle-button').textContent.includes('Disable')) {
          item.style.display = 'none';
        }
      });
    } else {
      hideShowButton.textContent = 'Hide Disabled';
      extensionItems.forEach(function(item) {
        item.style.display = 'block';
      });
    }
  });
  
  // Search functionality
  var searchInput = document.getElementById('search-input');
  searchInput.addEventListener('input', function() {
    var searchTerm = searchInput.value.toLowerCase();
    var extensionItems = document.querySelectorAll('.extension-item');
    extensionItems.forEach(function(item) {
      var extensionName = item.querySelector('.extension-name').textContent.toLowerCase();
      if (extensionName.includes(searchTerm)) {
        item.style.display = 'block'; // Show item if search term matches
      } else {
        item.style.display = 'none'; // Hide item if search term does not match
      }
    });
  });
  
  // Filter functionality
  var filterSelect = document.getElementById('filter-select');
  filterSelect.addEventListener('change', function() {
    var filterValue = filterSelect.value;
    var extensionItems = document.querySelectorAll('.extension-item');
    extensionItems.forEach(function(item) {
      var extensionType = item.querySelector('.extension-type').textContent.toLowerCase();
      if (filterValue === 'all' || extensionType === filterValue) {
        item.style.display = 'block'; // Show item if filter matches
      } else {
        item.style.display = 'none'; // Hide item if filter does not match
      }
    });
  });
}

// Run initialization when popup is loaded
document.addEventListener('DOMContentLoaded', function() {
  initializePopup();
});

// Funktion zum Umschalten aller Erweiterungen
function toggleAllExtensions() {
  chrome.management.getAll(function(extensions) {
    var allEnabled = extensions.every(function(extension) {
      return extension.enabled;
    });

    extensions.forEach(function(extension) {
      // Skip enabling/disabling the "NG Extension Manager"
      if (extension.id !== 'apafkmfdpkiodhnkcbliipcmpbghhgnj') {
        chrome.management.setEnabled(extension.id, !allEnabled);
      }
    });

    // Text des Buttons entsprechend aktualisieren
    var toggleButton = document.getElementById('toggle-button');
    toggleButton.textContent = allEnabled ? 'Enable All' : 'Disable All';
    
    // Nach dem Umschalten alle Erweiterungen neu anzeigen
    displayExtensions();
  });
}

// Event-Listener hinzufügen
document.addEventListener('DOMContentLoaded', function() {
  var toggleButton = document.getElementById('toggle-button');
  toggleButton.addEventListener('click', toggleAllExtensions);
});