// Funktion zum Anzeigen installierter Erweiterungen
function displayExtensions() {
  chrome.management.getAll(function(extensions) {
    var extensionList = document.getElementById('extension-list');
    extensionList.innerHTML = ''; // Vorherige Liste löschen

    // Variable zur Überprüfung, ob mindestens eine Erweiterung angezeigt wird
    let hasExtensions = false;

    extensions.forEach(function(extension) {
      // Überspringe die "NG Extension Manager" Erweiterung
      if (extension.id === 'ninhjdeipacebhgbhblhjglnaajfehio') {
        return;
      }

      // Erstelle Container für jede Erweiterung
      var extensionItem = document.createElement('div');
      extensionItem.classList.add('extension-item');

      // Erweiterungssymbol
      var icon = document.createElement('img');
      icon.src = extension.icons ? extension.icons[0].url : 'icons/128x128.png'; // Standard-Symbol, falls nicht verfügbar
      icon.alt = extension.name;
      icon.classList.add('extension-icon');

      // Erweiterungsname
      var name = document.createElement('span');
      name.textContent = truncate(extension.name, 25); // Lange Namen kürzen
      name.classList.add('extension-name');

      // Aktivieren/Deaktivieren Button
      var enableDisableButton = document.createElement('button');
      enableDisableButton.textContent = extension.enabled ? 'Disable' : 'Enable';
      enableDisableButton.classList.add('toggle-button');
      enableDisableButton.addEventListener('click', function() {
        chrome.management.setEnabled(extension.id, !extension.enabled, function() {
          displayExtensions(); // Erweiterungsliste nach Umschalten aktualisieren
        });
      });

      // Open Button (nur wenn es eine App ist)
      if (extension.type === 'hosted_app' || extension.type === 'packaged_app' || extension.type === 'legacy_packaged_app') {
        var openButton = document.createElement('button');
        openButton.textContent = 'Open';
        openButton.classList.add('open-button');
        openButton.addEventListener('click', function() {
          chrome.management.launchApp(extension.id);
        });
        extensionItem.appendChild(openButton); // Open Button hinzufügen
      }

      // Details Button
      var detailsButton = document.createElement('button');
      detailsButton.textContent = 'Details';
      detailsButton.classList.add('details-button');
      detailsButton.addEventListener('click', function() {
        showExtensionDetails(extension);
      });

      // Delete Button
      var deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.classList.add('delete-button');
      deleteButton.addEventListener('click', function() {
        if (confirm('Are you sure you want to delete this extension?')) {
          chrome.management.uninstall(extension.id, function() {
            displayExtensions(); // Erweiterungsliste nach Deinstallation aktualisieren
          });
        }
      });

      // *** Kebab Menu wurde entfernt ***
      // // Kebab Menu (Material Icon)
      // var kebabButton = document.createElement('button');
      // kebabButton.innerHTML = '<span class="material-icons">more_vert</span>';
      // kebabButton.classList.add('kebab-button');
      // kebabButton.addEventListener('click', function(event) {
      //   event.stopPropagation(); // Verhindert das Schließen des Bottom Sheets beim Klicken auf das Kebab
      //   openSettingsModal();
      // });

      // Elemente zum Erweiterungs-Item hinzufügen
      extensionItem.appendChild(icon);
      extensionItem.appendChild(name);
      extensionItem.appendChild(enableDisableButton);
      extensionItem.appendChild(detailsButton);
      extensionItem.appendChild(deleteButton);
      // *** Kebab Button wurde entfernt ***
      // extensionItem.appendChild(kebabButton); // Kebab Button hinzufügen
      extensionList.appendChild(extensionItem);

      hasExtensions = true;
    });

    // Fehlerbehandlung: Keine Erweiterungen gefunden
    if (!hasExtensions) {
      var noExtensionsMessage = document.createElement('p');
      noExtensionsMessage.textContent = 'No extensions found.';
      noExtensionsMessage.classList.add('no-extensions-message');
      extensionList.appendChild(noExtensionsMessage);
    }
  });
}

// Funktion zum Kürzen langer Erweiterungsnamen
function truncate(text, maxLength) {
  return text.length > maxLength ? text.substring(0, maxLength - 3) + '...' : text;
}

// Funktion zum Anzeigen der Erweiterungsdetails im Bottom Sheet
function showExtensionDetails(extension) {
  // Lade Einstellungen aus dem Local Storage
  var settings = getSettings();

  if (settings.redirectToDetails) {
    // Wenn die Einstellung aktiviert ist, öffne die vollständige Detailseite
    chrome.tabs.create({ url: 'details.html?id=' + extension.id });
    return;
  }

  // Andernfalls zeige das Bottom Sheet an
  // Überprüfe, ob das Bottom Sheet bereits existiert
  var existingSheet = document.getElementById('bottom-sheet');
  if (existingSheet) {
    existingSheet.remove(); // Entferne es, um ein neues zu erstellen
  }

  // Erstelle den Bottom Sheet Container
  var bottomSheet = document.createElement('div');
  bottomSheet.id = 'bottom-sheet';
  bottomSheet.classList.add('bottom-sheet'); // Gehe davon aus, dass CSS für .bottom-sheet definiert ist

  // Erstelle den Inhaltscontainer
  var content = document.createElement('div');
  content.classList.add('bottom-sheet-content');

  // Füge Erweiterungsdetails hinzu
  var name = document.createElement('p');
  name.innerHTML = `<strong>Name:</strong> ${extension.name}`;
  content.appendChild(name);

  var version = document.createElement('p');
  version.innerHTML = `<strong>Version:</strong> ${extension.version}`;
  content.appendChild(version);

  var homepage = document.createElement('p');
  homepage.innerHTML = `<strong>Homepage:</strong> <a href="${extension.homepageUrl || '#'}" target="_blank">${extension.homepageUrl || 'N/A'}</a>`;
  content.appendChild(homepage);

  // Entferne den Chrome Web Store Link wie gewünscht
  // var chromeStore = document.createElement('p');
  // chromeStore.innerHTML = `<strong>Chrome Web Store:</strong> <a href="${extension.optionsUrl || '#'}" target="_blank">${extension.optionsUrl ? 'View on Store' : 'N/A'}</a>`;
  // content.appendChild(chromeStore);

  // Button zum Anzeigen aller Details, abhängig von den Einstellungen
  if (!settings.hideViewAllButton) {
    var viewAllButton = document.createElement('button');
    viewAllButton.textContent = 'View All Details';
    viewAllButton.classList.add('view-all-button');
    viewAllButton.addEventListener('click', function() {
      chrome.tabs.create({ url: 'details.html?id=' + extension.id });
      closeBottomSheet();
    });
    content.appendChild(viewAllButton);
  }

  // *** Kebab Menu im Bottom Sheet ***
  var kebabButton = document.createElement('button');
  kebabButton.innerHTML = '<span class="material-icons">more_vert</span>';
  kebabButton.classList.add('kebab-button');
  kebabButton.addEventListener('click', function(event) {
    event.stopPropagation(); // Verhindert das Schließen des Bottom Sheets beim Klicken auf das Kebab
    openSettingsModal();
  });
  content.appendChild(kebabButton);

  // Schließen Button
  var closeButton = document.createElement('span');
  closeButton.classList.add('close-button');
  closeButton.innerHTML = '&times;';
  closeButton.addEventListener('click', closeBottomSheet);
  bottomSheet.appendChild(closeButton);

  bottomSheet.appendChild(content);
  document.body.appendChild(bottomSheet);

  // Trigger Reflow für Animation
  void bottomSheet.offsetWidth;

  // Zeige das Bottom Sheet
  bottomSheet.classList.add('active');
}

// Funktion zum Schließen des Bottom Sheets
function closeBottomSheet() {
  var bottomSheet = document.getElementById('bottom-sheet');
  if (bottomSheet) {
    bottomSheet.classList.remove('active');
    // Entferne das Bottom Sheet nach der Animation
    bottomSheet.addEventListener('transitionend', function() {
      bottomSheet.remove();
    });
  }
}

// Funktion zum Öffnen des Einstellungsmodals
function openSettingsModal() {
  // Überprüfe, ob das Modal bereits existiert
  var existingModal = document.getElementById('settings-modal');
  if (existingModal) {
    existingModal.remove(); // Entferne es, um ein neues zu erstellen
  }

  // Erstelle den Modal Container
  var modal = document.createElement('div');
  modal.id = 'settings-modal';
  modal.classList.add('modal'); // Gehe davon aus, dass CSS für .modal definiert ist

  // Erstelle den Modal Inhalt
  var modalContent = document.createElement('div');
  modalContent.classList.add('modal-content');

  // Schließen Button
  var closeButton = document.createElement('span');
  closeButton.classList.add('close-button');
  closeButton.innerHTML = '&times;';
  closeButton.addEventListener('click', closeSettingsModal);
  modalContent.appendChild(closeButton);

  // Titel
  var title = document.createElement('h2');
  title.textContent = 'Settings';
  modalContent.appendChild(title);

  // Option 1: Redirect zu vollständigen Details
  var redirectOption = document.createElement('div');
  redirectOption.classList.add('setting-option');

  var redirectLabel = document.createElement('label');
  redirectLabel.textContent = 'Redirect to full details page when clicking "Details"';
  redirectLabel.setAttribute('for', 'redirect-toggle');

  var redirectToggle = document.createElement('input');
  redirectToggle.type = 'checkbox';
  redirectToggle.id = 'redirect-toggle';
  redirectToggle.checked = getSettings().redirectToDetails;
  redirectToggle.addEventListener('change', function() {
    saveSetting('redirectToDetails', redirectToggle.checked);
  });

  redirectOption.appendChild(redirectToggle);
  redirectOption.appendChild(redirectLabel);
  modalContent.appendChild(redirectOption);

  // Option 2: Ausblenden des "View All Details" Buttons
  var hideViewAllOption = document.createElement('div');
  hideViewAllOption.classList.add('setting-option');

  var hideViewAllLabel = document.createElement('label');
  hideViewAllLabel.textContent = 'Hide "View All Details" button in Bottom Sheet';
  hideViewAllLabel.setAttribute('for', 'hide-viewall-toggle');

  var hideViewAllToggle = document.createElement('input');
  hideViewAllToggle.type = 'checkbox';
  hideViewAllToggle.id = 'hide-viewall-toggle';
  hideViewAllToggle.checked = getSettings().hideViewAllButton;
  hideViewAllToggle.addEventListener('change', function() {
    saveSetting('hideViewAllButton', hideViewAllToggle.checked);
  });

  hideViewAllOption.appendChild(hideViewAllToggle);
  hideViewAllOption.appendChild(hideViewAllLabel);
  modalContent.appendChild(hideViewAllOption);

  modal.appendChild(modalContent);
  document.body.appendChild(modal);

  // Zeige das Modal mit Animation
  setTimeout(function() {
    modal.classList.add('active');
  }, 10);
}

// Funktion zum Schließen des Einstellungsmodals
function closeSettingsModal() {
  var modal = document.getElementById('settings-modal');
  if (modal) {
    modal.classList.remove('active');
    // Entferne das Modal nach der Animation
    modal.addEventListener('transitionend', function() {
      modal.remove();
    });
  }
}

// Funktion zum Speichern einer Einstellung in Local Storage
function saveSetting(key, value) {
  let settings = JSON.parse(localStorage.getItem('extensionManagerSettings')) || {};
  settings[key] = value;
  localStorage.setItem('extensionManagerSettings', JSON.stringify(settings));
}

// Funktion zum Abrufen der Einstellungen aus Local Storage
function getSettings() {
  return JSON.parse(localStorage.getItem('extensionManagerSettings')) || {
    redirectToDetails: false,
    hideViewAllButton: false
  };
}

// Funktion zur Initialisierung des Popup
function initializePopup() {
  displayExtensions(); // Installierte Erweiterungen anzeigen

  // Hide/Show Button
  var hideShowButton = document.getElementById('hide-show-button');
  var hidden = false;
  hideShowButton.addEventListener('click', function() {
    hidden = !hidden;
    var extensionItems = document.querySelectorAll('.extension-item');
    if (hidden) {
      hideShowButton.textContent = 'Show Disabled';
      extensionItems.forEach(function(item) {
        if (!item.querySelector('.toggle-button').textContent.includes('Disable')) {
          item.style.display = 'none';
        }
      });
    } else {
      hideShowButton.textContent = 'Hide Disabled';
      extensionItems.forEach(function(item) {
        item.style.display = 'flex'; // Layout beibehalten
      });
    }
  });

  // Suchfunktionalität
  var searchInput = document.getElementById('search-input');
  searchInput.addEventListener('input', function() {
    var searchTerm = searchInput.value.toLowerCase();
    var extensionItems = document.querySelectorAll('.extension-item');
    let anyMatch = false;

    extensionItems.forEach(function(item) {
      var extensionName = item.querySelector('.extension-name').textContent.toLowerCase();
      if (extensionName.includes(searchTerm)) {
        item.style.display = 'flex'; // Layout beibehalten
        anyMatch = true;
      } else {
        item.style.display = 'none';
      }
    });

    // Zeige eine Nachricht an, wenn keine Erweiterungen gefunden wurden
    var extensionList = document.getElementById('extension-list');
    var noExtensionsMessage = document.querySelector('.no-extensions-message');
    if (!anyMatch) {
      if (!noExtensionsMessage) {
        var message = document.createElement('p');
        message.textContent = 'No extensions found.';
        message.classList.add('no-extensions-message');
        extensionList.appendChild(message);
      }
    } else {
      if (noExtensionsMessage) {
        noExtensionsMessage.remove();
      }
    }
  });

  // Schließe das Bottom Sheet, wenn außerhalb geklickt wird
  document.addEventListener('click', function(event) {
    var bottomSheet = document.getElementById('bottom-sheet');
    if (bottomSheet && !bottomSheet.contains(event.target) && !event.target.classList.contains('details-button') && !event.target.closest('.kebab-button')) {
      closeBottomSheet();
    }

    var modal = document.getElementById('settings-modal');
    if (modal && !modal.contains(event.target) && !event.target.closest('.kebab-button')) {
      closeSettingsModal();
    }
  });
}

// Initialisiere das Popup, wenn es geladen wird
document.addEventListener('DOMContentLoaded', function() {
  initializePopup();
});

// Funktion zum Umschalten aller Erweiterungen
function toggleAllExtensions() {
  chrome.management.getAll(function(extensions) {
    var allEnabled = extensions.every(function(extension) {
      return extension.enabled;
    });

    extensions.forEach(function(extension) {
      // Überspringe das Umschalten der "NG Extension Manager" Erweiterung
      if (extension.id !== 'apafkmfdpkiodhnkcbliipcmpbghhgnj') {
        chrome.management.setEnabled(extension.id, !allEnabled);
      }
    });

    // Aktualisiere den Text des Buttons entsprechend
    var toggleButton = document.getElementById('toggle-button');
    toggleButton.textContent = allEnabled ? 'Enable All' : 'Disable All';

    // Aktualisiere die Erweiterungsliste nach dem Umschalten
    displayExtensions();
  });
}

// Füge Event Listener hinzu
document.addEventListener('DOMContentLoaded', function() {
  var toggleButton = document.getElementById('toggle-button');
  toggleButton.addEventListener('click', toggleAllExtensions);
});
