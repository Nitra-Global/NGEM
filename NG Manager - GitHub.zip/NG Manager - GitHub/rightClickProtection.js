function createCustomContextMenu() {
    const contextMenu = document.createElement('div');
    contextMenu.id = 'custom-context-menu';
    contextMenu.style.position = 'absolute';
    contextMenu.style.backgroundColor = '#111';
    contextMenu.style.border = 'none';
    contextMenu.style.borderRadius = '12px';
    contextMenu.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
    contextMenu.style.display = 'none';
    contextMenu.style.zIndex = '9999';
    contextMenu.style.padding = '8px 0';
    contextMenu.style.fontFamily = 'Inter, sans-serif';
    contextMenu.style.minWidth = '180px';
    contextMenu.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    contextMenu.style.opacity = '0';
    contextMenu.style.transform = 'scale(0.9)';

    // Optionen des Kontextmenüs
    const options = [
        { text: 'Reload', action: () => window.location.reload(), icon: 'refresh' },
        { text: 'Copy URL', action: copyPageURL, icon: 'link' },
        { text: 'Pin/Unpin', action: togglePinTab, icon: 'push_pin' },
        { text: 'Open in New Window', action: () => window.open(window.location.href, '_blank'), icon: 'open_in_new' },
        { text: 'Settings', action: openSettings, icon: 'settings' }
    ];

    // Erstellen der Menüelemente
    const menuItems = options.map(option => {
        const menuItem = document.createElement('div');
        menuItem.className = 'menu-item';
        menuItem.style.padding = '10px 16px';
        menuItem.style.cursor = 'pointer';
        menuItem.style.display = 'flex';
        menuItem.style.alignItems = 'center';
        menuItem.style.borderBottom = '1px solid #333';
        menuItem.style.color = '#fff';
        menuItem.style.transition = 'background-color 0.3s ease, transform 0.2s ease';
        menuItem.style.borderRadius = '8px';
        menuItem.innerHTML = `
            <span class="material-icons" style="margin-right: 8px; color: #aaa;">${option.icon}</span>
            <span>${option.text}</span>
        `;
        menuItem.addEventListener('click', option.action);
        menuItem.addEventListener('mouseover', () => {
            menuItem.style.backgroundColor = '#333';
            menuItem.style.transform = 'scale(1.02)';
        });
        menuItem.addEventListener('mouseout', () => {
            menuItem.style.backgroundColor = 'transparent';
            menuItem.style.transform = 'scale(1)';
        });
        return menuItem;
    });

    // Sortieren der Menüelemente nach einem benutzerdefinierten Kriterium (z.B. alphabetisch)
    menuItems.sort((a, b) => a.textContent.localeCompare(b.textContent));

    menuItems.forEach(menuItem => contextMenu.appendChild(menuItem));
    contextMenu.lastChild.style.borderBottom = 'none';

    document.body.appendChild(contextMenu);

    // Kontextmenü öffnen
    document.addEventListener('contextmenu', (e) => {
        if (localStorage.getItem('contextMenuEnabled') === 'false') return;

        e.preventDefault();
        contextMenu.style.left = `${e.pageX}px`;
        contextMenu.style.top = `${e.pageY}px`;
        contextMenu.style.display = 'block';
        contextMenu.style.opacity = '1';
        contextMenu.style.transform = 'scale(1)';
    });

    // Kontextmenü schließen
    document.addEventListener('click', () => {
        contextMenu.style.opacity = '0';
        contextMenu.style.transform = 'scale(0.9)';
        setTimeout(() => {
            contextMenu.style.display = 'none';
        }, 300);
    });

    // ESC-Tastenkürzel zum Schließen des Menüs
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            contextMenu.style.opacity = '0';
            contextMenu.style.transform = 'scale(0.9)';
            setTimeout(() => {
                contextMenu.style.display = 'none';
            }, 300);
        }
    });
}

// Funktion zum Deaktivieren des Text-Kopierens
function disableTextSelection() {
    document.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('mousedown', (e) => {
        if (localStorage.getItem('textCopyEnabled') === 'false') {
            e.preventDefault();
        }
    });
}

// Funktion zum Aktivieren oder Deaktivieren des Text-Kopierens
function toggleTextCopy(enabled) {
    localStorage.setItem('textCopyEnabled', enabled);
    if (enabled === 'false') {
        disableTextSelection();
    } else {
        document.removeEventListener('contextmenu', (e) => e.preventDefault());
        document.removeEventListener('mousedown', (e) => {
            if (localStorage.getItem('textCopyEnabled') === 'false') {
                e.preventDefault();
            }
        });
    }
}

// Funktion zum Öffnen des Einstellungsmenüs
function openSettings() {
    let settingsMenu = document.getElementById('settings-menu');
    if (!settingsMenu) {
        settingsMenu = document.createElement('div');
        settingsMenu.id = 'settings-menu';
        settingsMenu.style.position = 'fixed';
        settingsMenu.style.top = '20px';
        settingsMenu.style.right = '20px';
        settingsMenu.style.backgroundColor = '#111';
        settingsMenu.style.border = '1px solid #333';
        settingsMenu.style.borderRadius = '18px';
        settingsMenu.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.25)';
        settingsMenu.style.zIndex = '10000';
        settingsMenu.style.fontFamily = 'Inter, sans-serif';
        settingsMenu.style.padding = '20px';
        settingsMenu.style.display = 'none';
        settingsMenu.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        settingsMenu.style.opacity = '0';
        settingsMenu.style.transform = 'scale(0.9)';
        settingsMenu.innerHTML = `
            <h3 style="color: #fff;">Settings</h3>
            <label style="color: #fff;">
                <input type="checkbox" id="context-menu-toggle" ${localStorage.getItem('contextMenuEnabled') === 'false' ? '' : 'checked'}>
                Enable Custom Context Menu
            </label>
            <label style="color: #fff; display: block; margin-top: 10px;">
                Text Copy: 
                <input type="checkbox" id="text-copy-toggle" ${localStorage.getItem('textCopyEnabled') === 'false' ? '' : 'checked'}>
                Enable Text Copy
            </label>
            <label style="color: #fff; display: block; margin-top: 10px;">
                Menu Transparency: 
                <input type="range" id="menu-transparency" min="0" max="100" value="${localStorage.getItem('menuTransparency') || '100'}">
                <span id="transparency-value">${localStorage.getItem('menuTransparency') || '100'}%</span>
            </label>
            <label style="color: #fff; display: block; margin-top: 10px;">
                Menu Size: 
                <input type="range" id="menu-size" min="50" max="300" value="${localStorage.getItem('menuSize') || '180'}">
                <span id="size-value">${localStorage.getItem('menuSize') || '180'}px</span>
            </label>
            <label style="color: #fff; display: block; margin-top: 10px;">
                Menu Item Background Color: 
                <input type="color" id="menu-bg-color" value="${localStorage.getItem('menuBgColor') || '#111'}">
            </label>
            <label style="color: #fff; display: block; margin-top: 10px;">
                Menu Item Text Color: 
                <input type="color" id="menu-text-color" value="${localStorage.getItem('menuTextColor') || '#fff'}">
            </label>
            <label style="color: #fff; display: block; margin-top: 10px;">
                Animation Effect: 
                <select id="animation-effect">
                    <option value="scale" ${localStorage.getItem('animationEffect') === 'scale' ? 'selected' : ''}>Scale</option>
                    <option value="fade" ${localStorage.getItem('animationEffect') === 'fade' ? 'selected' : ''}>Fade</option>
                </select>
            </label>
            <p style="color: #fff;">Press <strong>Ctrl+Shift+S</strong> to toggle settings menu.</p>
            <button id="close-settings" style="margin-top: 10px; padding: 8px 16px; border: none; background-color: #007bff; color: #fff; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease;">Close</button>
        `;
        document.body.appendChild(settingsMenu);

        // Event Listener für das Schließen des Einstellungsmenüs
        document.getElementById('close-settings').addEventListener('click', () => {
            settingsMenu.style.opacity = '0';
            settingsMenu.style.transform = 'scale(0.9)';
            setTimeout(() => {
                settingsMenu.style.display = 'none';
            }, 300);
        });

        // Event Listener für das Umschalten des Kontextmenüs
        document.getElementById('context-menu-toggle').addEventListener('change', (e) => {
            localStorage.setItem('contextMenuEnabled', e.target.checked);
            if (e.target.checked) {
                showNotification('Custom context menu enabled.');
            } else {
                showNotification('Custom context menu disabled.');
            }
        });

        // Event Listener für das Umschalten der Text-Kopierfunktion
        document.getElementById('text-copy-toggle').addEventListener('change', (e) => {
            toggleTextCopy(e.target.checked);
            if (e.target.checked) {
                showNotification('Text copy enabled.');
            } else {
                showNotification('Text copy disabled.');
            }
        });

        // Event Listener für die Transparenz des Menüs
        document.getElementById('menu-transparency').addEventListener('input', (e) => {
            const transparency = e.target.value;
            localStorage.setItem('menuTransparency', transparency);
            document.getElementById('transparency-value').textContent = `${transparency}%`;
            document.getElementById('custom-context-menu').style.backgroundColor = `rgba(17, 17, 17, ${transparency / 100})`;
        });

        // Event Listener für die Größe des Menüs
        document.getElementById('menu-size').addEventListener('input', (e) => {
            const size = e.target.value;
            localStorage.setItem('menuSize', size);
            document.getElementById('size-value').textContent = `${size}px`;
            document.getElementById('custom-context-menu').style.minWidth = `${size}px`;
        });

        // Event Listener für die Hintergrundfarbe der Menüelemente
        document.getElementById('menu-bg-color').addEventListener('input', (e) => {
            const color = e.target.value;
            localStorage.setItem('menuBgColor', color);
            document.querySelectorAll('.menu-item').forEach(item => {
                item.style.backgroundColor = color;
            });
        });

        // Event Listener für die Textfarbe der Menüelemente
        document.getElementById('menu-text-color').addEventListener('input', (e) => {
            const color = e.target.value;
            localStorage.setItem('menuTextColor', color);
            document.querySelectorAll('.menu-item').forEach(item => {
                item.style.color = color;
            });
        });

        // Event Listener für den Animationseffekt
        document.getElementById('animation-effect').addEventListener('change', (e) => {
            localStorage.setItem('animationEffect', e.target.value);
            updateMenuAnimation();
        });

        // Initialisieren der Menüoptionen basierend auf den gespeicherten Werten
        document.getElementById('menu-transparency').value = localStorage.getItem('menuTransparency') || '100';
        document.getElementById('size-value').textContent = `${localStorage.getItem('menuSize') || '180'}px`;
        document.getElementById('menu-bg-color').value = localStorage.getItem('menuBgColor') || '#111';
        document.getElementById('menu-text-color').value = localStorage.getItem('menuTextColor') || '#fff';
        document.getElementById('animation-effect').value = localStorage.getItem('animationEffect') || 'scale';

        // Update der Menüanimation basierend auf der gespeicherten Einstellung
        updateMenuAnimation();
    }

    settingsMenu.style.display = 'block';
    settingsMenu.style.opacity = '1';
    settingsMenu.style.transform = 'scale(1)';
}

// Initiales Setup
toggleTextCopy(localStorage.getItem('textCopyEnabled') || 'true');
createCustomContextMenu();


// Funktion zum Aktualisieren der Menüanimation basierend auf den gespeicherten Einstellungen
function updateMenuAnimation() {
    const effect = localStorage.getItem('animationEffect') || 'scale';
    const contextMenu = document.getElementById('custom-context-menu');
    if (effect === 'scale') {
        contextMenu.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    } else if (effect === 'fade') {
        contextMenu.style.transition = 'opacity 0.3s ease';
        contextMenu.style.transform = 'none';
    }
}

// Funktion zum Kopieren der aktuellen Seiten-URL
function copyPageURL() {
    navigator.clipboard.writeText(window.location.href)
        .then(() => {
            showNotification('Page URL copied to clipboard!');
        })
        .catch(err => {
            console.error('Failed to copy URL: ', err);
            showNotification('Failed to copy URL.');
        });
}

// Funktion zum Umschalten des Pins eines Tabs
function togglePinTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        chrome.tabs.update(tab.id, { pinned: !tab.pinned });
    });
}

// Funktion zum Anzeigen von Benachrichtigungen
function showNotification(message) {
    const notification = document.createElement('div');
    notification.id = 'notification';
    notification.style.position = 'fixed';
    notification.style.top = '10px';
    notification.style.right = '10px';
    notification.style.backgroundColor = '#111';
    notification.style.color = '#fff';
    notification.style.padding = '10px 20px';
    notification.style.borderRadius = '8px';
    notification.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
    notification.style.zIndex = '10001';
    notification.style.fontFamily = 'Inter, sans-serif';
    notification.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    notification.style.opacity = '0';
    notification.style.transform = 'translateY(-20px)';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(0)';
    }, 10);

    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-20px)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Funktion zum Überwachen des Tastendrucks für das Einstellungsmenü
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'S') {
        openSettings();
    }
});

// Erstellen des benutzerdefinierten Kontextmenüs
createCustomContextMenu();
