document.addEventListener('DOMContentLoaded', () => {
    document.body.addEventListener('click', (event) => {
        const link = event.target.closest('a');
        if (link && link.href && link.hostname !== window.location.hostname) {
            event.preventDefault();
            const sanitizedUrl = sanitizeURL(link.href);
            if (isSafeURL(sanitizedUrl)) {
                showPopup(sanitizedUrl);
            } else {
                showErrorPopup('The URL you are trying to access is not allowed.');
            }
        }
    });
});

function showPopup(url) {
    const overlay = createOverlay();
    const popup = createPopup(url);

    document.body.append(overlay, popup);

    setTimeout(() => {
        overlay.style.opacity = '1';
        popup.style.opacity = '1';
        popup.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 10);

    document.getElementById('confirm-leave').addEventListener('click', () => {
        document.getElementById('confirm-leave').disabled = true;
        document.getElementById('cancel-leave').disabled = true;
        showSpinner();
        setTimeout(() => {
            try {
                window.open(url, '_blank');
                closePopup(popup, overlay);
            } catch (error) {
                closePopup(popup, overlay);
                showErrorPopup('An error occurred while trying to open the URL.');
            }
        }, 1300);
    });

    document.getElementById('cancel-leave').addEventListener('click', () => closePopup(popup, overlay));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') closePopup(popup, overlay);
    });
}

function createOverlay() {
    const overlay = document.createElement('div');
    Object.assign(overlay.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        zIndex: '9999',
        opacity: '0',
        transition: 'opacity 0.4s ease',
    });
    return overlay;
}

function createPopup(url) {
    const isHttps = url.startsWith('https://');
    const linkColor = isHttps ? '#1a73e8' : '#dc3545';

    const popup = document.createElement('div');
    Object.assign(popup.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%) scale(0.8)',
        backgroundColor: '#111',
        borderRadius: '18px',
        padding: '20px',
        boxShadow: '0 8px 16px rgba(0, 0, 0, 0.5)',
        zIndex: '10000',
        maxWidth: '90%',
        boxSizing: 'border-box',
        fontFamily: 'Inter, sans-serif',
        fontSize: '16px',
        transition: 'transform 0.4s ease, opacity 0.4s ease',
        opacity: '0',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        color: '#111'
    });

    popup.innerHTML = `
        <h1 style="font-size: 22px; color: #eee; margin-bottom: 15px; font-weight: bold;">Leaving NG Extension Manager</h1>
        <p style="font-size: 16px; color: #ccc; margin-bottom: 15px;">You are about to navigate away from the NG Extension Manager. Do you wish to continue?</p>
        <p style="font-size: 16px; color: ${linkColor}; word-wrap: break-word; margin-bottom: 20px;">${url}</p>
        ${!isHttps ? '<p style="font-size: 14px; color: #dc3545; margin-bottom: 20px;">Warning: This link is not secure (no HTTPS). Proceed with caution.</p>' : ''}
        <div style="margin-bottom: 20px;">
            <button id="confirm-leave" style="padding: 12px 24px; border: none; border-radius: 6px; background-color: #1a73e8; color: #fff; cursor: pointer; font-size: 16px; margin-right: 10px; transition: background-color 0.3s ease;">Yes, Continue</button>
            <button id="cancel-leave" style="padding: 12px 24px; border: none; border-radius: 6px; background-color: #333; color: #eee; cursor: pointer; font-size: 16px; transition: background-color 0.3s ease;">No, Cancel</button>
        </div>
        <div id="spinner-container" style="display: none; text-align: center;">
            <div id="spinner"></div>
            <p style="font-size: 14px; color: #ccc; margin-top: 10px;">Redirecting, please wait...</p>
        </div>
    `;

    return popup;
}

function closePopup(popup, overlay) {
    popup.style.opacity = '0';
    popup.style.transform = 'translate(-50%, -50%) scale(0.8)';
    overlay.style.opacity = '0';
    setTimeout(() => {
        popup.remove();
        overlay.remove();
    }, 400);
}

function showSpinner() {
    document.getElementById('spinner-container').style.display = 'block';
}

function showErrorPopup(message) {
    const overlay = createOverlay();
    const errorPopup = createErrorPopup(message);

    document.body.append(overlay, errorPopup);

    setTimeout(() => {
        overlay.style.opacity = '1';
        errorPopup.style.opacity = '1';
        errorPopup.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 10);

    document.getElementById('error-close').addEventListener('click', () => closePopup(errorPopup, overlay));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') closePopup(errorPopup, overlay);
    });
}

function createErrorPopup(message) {
    const errorPopup = document.createElement('div');
    Object.assign(errorPopup.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%) scale(0.8)',
        backgroundColor: '#111',
        borderRadius: '18px',
        padding: '20px',
        boxShadow: '0 8px 16px rgba(0, 0, 0, 0.5)',
        zIndex: '10000',
        maxWidth: '90%',
        boxSizing: 'border-box',
        fontFamily: 'Inter, sans-serif',
        fontSize: '16px',
        transition: 'transform 0.4s ease, opacity 0.4s ease',
        opacity: '0',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        textAlign: 'center',
        color: '#111'
    });

    errorPopup.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 15px;">
            <span style="font-size: 24px; color: #dc3545; margin-right: 10px;" class="material-icons">error</span>
            <h1 style="font-size: 22px; color: #eee; margin: 0;">Error</h1>
        </div>
        <p style="font-size: 16px; color: #ccc; margin-bottom: 20px;">${message}</p>
        <button id="error-close" style="padding: 12px 24px; border: none; border-radius: 6px; background-color: #dc3545; color: #fff; cursor: pointer; font-size: 16px; transition: background-color 0.3s ease;">Close</button>
    `;

    return errorPopup;
}

function sanitizeURL(url) {
    try {
        const sanitizedURL = decodeURI(url);
        return encodeURI(sanitizedURL);
    } catch (e) {
        // Falls die URL nicht dekodierbar ist, wird ein leeres String zurückgegeben
        return '';
    }
}

function isSafeURL(url) {
    const unsafeProtocols = /^(chrome|chrome-extension|chrome-devtools|about|javascript|data|file|ftp|mailto|view-source|ws|wss|smb|sftp|telnet|gopher|nntp|news|irc|ircs):/i;
    return !unsafeProtocols.test(url);
}

// CSS for Modern, Simple Spinner and Error Icon
const style = document.createElement('style');
style.textContent = `
    #spinner {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: 4px solid rgba(0, 0, 0, 0.1);
        border-top: 4px solid #eee;
        animation: spin 1s linear infinite;
        margin: 0 auto;
    }
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

`;
document.head.appendChild(style);