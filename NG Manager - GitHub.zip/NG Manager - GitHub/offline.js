// Function to check offline status and set the offline mode
function checkOfflineStatus() {
    if (!navigator.onLine) {
        enableOfflineMode();
        showOfflineWarning();
    } else {
        disableOfflineMode();
    }
}

// Enable offline mode with restricted access
function enableOfflineMode() {
    const elements = document.querySelectorAll('img, script, link, iframe, video, audio');
    elements.forEach(element => {
        const src = element.src || element.href;
        if (src && !src.endsWith('offline.js')) {
            element.style.display = 'none'; // Hide restricted resources
        }
    });
}

// Disable offline mode and restore functionality
function disableOfflineMode() {
    const elements = document.querySelectorAll('img, script, link, iframe, video, audio');
    elements.forEach(element => {
        element.style.display = ''; // Show all elements
    });
}

// Show an offline warning with alternative options
function showOfflineWarning() {
    const style = document.createElement('style');
    style.textContent = `
        #offline-warning {
            background-color: #f57c00;
            color: white;
            padding: 20px;
            position: fixed;
            top: 10%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10000;
            font-family: 'Inter', sans-serif;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            text-align: center;
            width: 80%;
            max-width: 400px;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
    document.head.appendChild(style);

    const warning = document.createElement('div');
    warning.id = 'offline-warning';
    warning.setAttribute('role', 'alert'); // Accessibility: alert role
    warning.innerHTML = `
        <strong>You are in Offline Mode!</strong><br>
        Some features may be restricted. You can still access previously loaded content.<br>
        <small>Please reconnect to access full functionality.</small>
    `;

    // Prevent duplication of warning
    if (!document.getElementById('offline-warning')) {
        document.body.appendChild(warning);
    }
}

// Check offline status on page load
window.addEventListener('load', checkOfflineStatus);

// Check offline status when network connection changes
window.addEventListener('offline', checkOfflineStatus);
window.addEventListener('online', checkOfflineStatus);
