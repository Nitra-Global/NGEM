// offline.js

// Funktion, um den Offline-Status zu überprüfen und alle Ressourcen zu blockieren, wenn offline
function checkOfflineStatus() {
    if (!navigator.onLine) {
        blockAllResources();
        showAccessDeniedWarning();
    }
}

// Ressourcen blockieren, außer offline.js
function blockAllResources() {
    const elements = document.querySelectorAll('img, script, link, iframe, video, audio');
    elements.forEach(element => {
        const src = element.src || element.href;
        if (!src || !src.endsWith('offline.js')) {
            element.remove();
        }
    });
}

// Warnung anzeigen, dass der Zugang verweigert wird
function showAccessDeniedWarning() {
    const style = document.createElement('style');
    style.textContent = `
        #access-denied-warning {
            background-color: #d32f2f;
            color: white;
            padding: 20px;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10000;
            font-family: 'Inter', sans-serif;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            text-align: center;
            width: 80%;
            max-width: 400px;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
    document.head.appendChild(style);

    const warning = document.createElement('div');
    warning.id = 'access-denied-warning';
    warning.innerHTML = `
        You are offline. Go online to view the page correctly.
    `;

    document.body.appendChild(warning);
}

// Überprüfe beim Laden der Seite den Offline-Status
window.addEventListener('load', checkOfflineStatus);

// Überprüfe den Offline-Status, wenn sich die Netzwerkverbindung ändert
window.addEventListener('offline', checkOfflineStatus);

// Entferne die Warnung und lade Ressourcen neu, wenn der Benutzer wieder online ist
window.addEventListener('online', () => {
    const warning = document.getElementById('access-denied-warning');
    if (warning) {
        warning.remove();
        location.reload(); // Seite neu laden, um Ressourcen zu laden
    }
});
