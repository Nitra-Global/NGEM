// Constants for pagination
const RESULTS_PER_PAGE = 50; // Number of entries per page
let currentPage = 1;
let totalResults = 0;
let totalPages = 0;

// Function to load history entries
async function loadHistory(page = 1, searchQuery = '') {
    const historyList = document.getElementById('history-list');
    const errorMessage = document.getElementById('error-message');

    historyList.innerHTML = ''; // Clear the list before loading new entries

    // Fetch ads from SearchAds.json
    const ads = await fetchAds();

    // Fetch history entries from Chrome API
    chrome.history.search({
        text: searchQuery, // Use the search query
        maxResults: 10000, // Fetch a large number of results to paginate through
        startTime: 0, // Fetch entries from the start of time
        endTime: Date.now() // Fetch entries up to the current time
    }, (results) => {
        if (!results || results.length === 0) {
            errorMessage.classList.add('visible');
            totalResults = 0;
            totalPages = 0;
            updatePaginationControls();
            return;
        }

        errorMessage.classList.remove('visible'); // Hide error message

        // Paginate results manually
        totalResults = results.length;
        totalPages = Math.ceil(totalResults / RESULTS_PER_PAGE);
        const startIndex = (page - 1) * RESULTS_PER_PAGE;
        const paginatedResults = results.slice(startIndex, startIndex + RESULTS_PER_PAGE);

        // Insert a grid of ads at regular intervals
        if (ads.length > 0) {
            const adFrequency = 30; // Show ads after every 30 entries
            for (let i = adFrequency - 1; i < paginatedResults.length; i += adFrequency) {
                const adItems = ads.slice(0, 3).map(ad => createAdItem(ad)).join('');
                const adGrid = createAdGrid(adItems);
                paginatedResults.splice(i, 0, { ad: adGrid }); // Insert grid of ads
            }
        }

        paginatedResults.forEach((entry) => {
            const listItem = document.createElement('li');
            listItem.classList.add('history-item');
            
            if (entry.ad) {
                // If this is an ad, insert the ad grid
                listItem.innerHTML = entry.ad;
                listItem.classList.add('ad-item'); // Optional: Add a class for styling ads
            } else {
                // Normal history entry
                listItem.innerHTML = `
                    <input type="checkbox" class="history-checkbox">
                    <span class="history-text">${entry.title || entry.url}</span>
                    <button class="details-item" data-url="${entry.url}">Details</button>
                    <button class="delete-item" data-url="${entry.url}">Delete</button>
                `;
            }

            historyList.appendChild(listItem);
        });

        // Add event listeners for delete and details buttons
        document.querySelectorAll('.delete-item').forEach(button => {
            button.addEventListener('click', () => {
                const url = button.getAttribute('data-url');
                deleteEntry(url);
            });
        });

        document.querySelectorAll('.details-item').forEach(button => {
            button.addEventListener('click', () => {
                const url = button.getAttribute('data-url');
                showDetails(url);
            });
        });

        // Update pagination controls
        updatePaginationControls();
    });
}

// Function to fetch ads from SearchAds.json
async function fetchAds() {
    try {
        const response = await fetch('SearchAds.json');
        const data = await response.json();
        return data.ads || []; // Assuming "ads" array exists in the JSON
    } catch (error) {
        console.error('Error fetching ads:', error);
        return [];
    }
}

// Function to create an ad element
function createAdItem(ad) {
    return `
        <div class="ad-item">
            <span class="ad-badge">Ad</span>
            <strong class="ad-title">${ad.title}</strong>
            <p class="ad-description">${ad.description}</p>
            <a href="${ad.url}" target="_blank" class="ad-link">Learn More</a>
        </div>
    `;
}

// Function to create an ad grid
function createAdGrid(adItems) {
    return `
        <div class="ad-grid">
            ${adItems}
        </div>
    `;
}

// Function to delete a history entry
function deleteEntry(url) {
    chrome.history.deleteUrl({ url }, () => {
        const button = document.querySelector(`.delete-item[data-url="${url}"]`);
        if (button) {
            button.parentElement.remove();
        }
    });
}

// Function to format date and time
function formatDateTime(timestamp) {
    return new Date(timestamp).toLocaleString(); // Convert timestamp to readable date and time
}

// Function to show details in a popup
function showDetails(url) {
    chrome.history.getVisits({ url }, (visits) => {
        const detailsPopup = document.getElementById('details-popup');
        const detailsInfo = document.getElementById('details-info');

        if (!detailsPopup || !detailsInfo) {
            console.error('Popup elements not found.');
            return;
        }

        // Clear existing details
        detailsInfo.innerHTML = '';

        // Add URL and other details
        detailsInfo.innerHTML = `
            <p><strong>URL:</strong> ${url}</p>
            <p><strong>Visit Count:</strong> ${visits.length}</p>
            <p><strong>First Visit:</strong> ${visits.length > 0 ? formatDateTime(visits[0].visitTime) : 'N/A'}</p>
            <p><strong>Last Visit:</strong> ${visits.length > 0 ? formatDateTime(visits[visits.length - 1].visitTime) : 'N/A'}</p>
        `;

        // Show the popup
        detailsPopup.style.display = 'flex';
    });
}

// Event listener to close the popup
document.getElementById('close-popup').addEventListener('click', () => {
    document.getElementById('details-popup').style.display = 'none';
});

// Event listener for delete all button
document.getElementById('delete-all-btn').addEventListener('click', () => {
    if (confirm('Are you sure you want to delete all entries?')) {
        chrome.history.deleteAll(() => {
            document.querySelectorAll('.history-list li').forEach(item => {
                item.remove();
            });
            document.getElementById('error-message').classList.remove('visible'); // Hide error message if all entries are deleted
            totalResults = 0;
            totalPages = 0;
            updatePaginationControls(); // Update pagination controls after deletion
        });
    }
});

// Event listener for delete selected button
document.getElementById('delete-selected-btn').addEventListener('click', () => {
    if (confirm('Are you sure you want to delete the selected entries?')) {
        document.querySelectorAll('.history-checkbox:checked').forEach(checkbox => {
            const url = checkbox.parentElement.querySelector('button.delete-item').getAttribute('data-url');
            chrome.history.deleteUrl({ url }, () => {
                checkbox.parentElement.remove();
            });
        });
    }
});

// Event listener for search button
document.getElementById('search-btn').addEventListener('click', () => {
    const searchQuery = document.getElementById('search-input').value;
    currentPage = 1; // Reset to first page on new search
    loadHistory(currentPage, searchQuery);
});

// Function to update pagination controls
function updatePaginationControls() {
    const paginationControls = document.getElementById('pagination-controls');
    if (!paginationControls) {
        console.error('Pagination controls element not found.');
        return;
    }

    paginationControls.innerHTML = '';

    // Create previous page button
    if (currentPage > 1) {
        const prevButton = document.createElement('button');
        prevButton.textContent = 'Previous';
        prevButton.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                loadHistory(currentPage, document.getElementById('search-input').value);
            }
        });
        paginationControls.appendChild(prevButton);
    }

    // Create next page button
    if (currentPage < totalPages) {
        const nextButton = document.createElement('button');
        nextButton.textContent = 'Next';
        nextButton.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                loadHistory(currentPage, document.getElementById('search-input').value);
            }
        });
        paginationControls.appendChild(nextButton);
    }
}

// Initial load of history
document.addEventListener('DOMContentLoaded', () => {
    loadHistory(currentPage);
});
