document.addEventListener('DOMContentLoaded', function() {
    const themeSwitcher = document.getElementById('theme-switcher');
    const body = document.body;
  
    // Load the saved theme from Local Storage
    const savedTheme = localStorage.getItem('theme');
  
    // Set the initial theme based on saved preference or default to dark mode
    if (savedTheme === 'light') {
      body.classList.add('light');
      themeSwitcher.checked = true; // Switcher will reflect Light Mode
    } else {
      body.classList.remove('light'); // Default to Dark Mode
    }
  
    // Event listener for theme switch
    themeSwitcher.addEventListener('change', function() {
      if (this.checked) {
        body.classList.add('light');
        localStorage.setItem('theme', 'light');
      } else {
        body.classList.remove('light');
        localStorage.setItem('theme', 'dark');
      }
    });
  });
  