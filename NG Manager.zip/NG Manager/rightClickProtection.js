(function() {
    // Dynamisch Inter-Schriftart und Material Icons laden
    const loadResources = () => {
        const interLink = document.createElement('link');
        interLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap';
        interLink.rel = 'stylesheet';
        document.head.appendChild(interLink);

        const materialIconsLink = document.createElement('link');
        materialIconsLink.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';
        materialIconsLink.rel = 'stylesheet';
        document.head.appendChild(materialIconsLink);
    };

    // Dynamisch CSS-Stile hinzufügen
    const injectStyles = () => {
        const style = document.createElement('style');
        style.textContent = `
            /* Kontextmenü Overlay */
            .custom-context-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(255, 255, 255, 0.0);
                z-index: 9998;
                display: none;
            }

            /* Kontextmenü Container */
            .custom-context-menu {
                position: absolute;
                background-color: #fff;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                padding: 8px 0;
                min-width: 180px;
                max-width: 300px;
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                color: #333;
                display: none;
                flex-direction: column;
                transition: opacity 0.3s ease, transform 0.3s ease;
                opacity: 0;
                transform: scale(0.95);
                z-index: 9999;
            }

            .custom-context-menu.visible {
                display: flex;
                opacity: 1;
                transform: scale(1);
            }

            /* Menüelemente */
            .custom-context-menu .menu-item {
                display: flex;
                align-items: center;
                padding: 10px 16px;
                cursor: pointer;
                transition: background-color 0.2s ease, transform 0.2s ease;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                position: relative;
            }

            .custom-context-menu .menu-item:hover {
                background-color: #f0f0f0;
                transform: translateX(2px);
            }

            .custom-context-menu .menu-item .material-icons {
                margin-right: 8px;
                color: #555;
                font-size: 18px;
            }

            /* Untermenü */
            .custom-context-menu .submenu {
                position: absolute;
                top: 0;
                left: 100%;
                margin-left: -4px;
                background-color: #fff;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                padding: 8px 0;
                min-width: 180px;
                max-width: 300px;
                display: none;
                flex-direction: column;
                transition: opacity 0.3s ease, transform 0.3s ease;
                opacity: 0;
                transform: scale(0.95);
                z-index: 10000;
            }

            .custom-context-menu .menu-item:hover .submenu {
                display: flex;
                opacity: 1;
                transform: scale(1);
            }

            /* Benachrichtigungen */
            .custom-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background-color: #fff;
                color: #333;
                padding: 12px 20px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                opacity: 0;
                transform: translateY(-20px);
                transition: opacity 0.3s ease, transform 0.3s ease;
                z-index: 10001;
            }

            .custom-notification.visible {
                opacity: 1;
                transform: translateY(0);
            }

            /* Responsive Design */
            @media (max-width: 400px) {
                .custom-context-menu {
                    min-width: 150px;
                    max-width: 250px;
                }

                .custom-context-menu .menu-item {
                    padding: 8px 12px;
                    font-size: 13px;
                }
            }
        `;
        document.head.appendChild(style);
    };

    // Utility Funktion zum Escaping von HTML
    const escapeHTML = (str) => {
        return String(str).replace(/[&<>"'`=\/]/g, function (s) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;',
                '/': '&#x2F;',
                '`': '&#x60;',
                '=': '&#x3D;'
            })[s];
        });
    };

    // Funktion zum Erstellen des Kontextmenüs
    const createCustomContextMenu = () => {
        try {
            // Overlay erstellen
            const overlay = document.createElement('div');
            overlay.classList.add('custom-context-overlay');
            document.body.appendChild(overlay);

            // Kontextmenü Container erstellen
            const contextMenu = document.createElement('div');
            contextMenu.classList.add('custom-context-menu');

            // Menüoptionen definieren
            const options = [
                { text: 'Reload', action: () => window.location.reload(), icon: 'refresh' },
                { text: 'Copy URL', action: copyPageURL, icon: 'link' },
                { text: 'Open DevTools', action: openCustomDevTools, icon: 'build' },
                { text: 'Open in New Window', action: () => window.open(window.location.href, '_blank'), icon: 'open_in_new' }
            ];

            // Menüelemente erstellen
            options.forEach(option => {
                const menuItem = document.createElement('div');
                menuItem.classList.add('menu-item');
                menuItem.innerHTML = `
                    <span class="material-icons">${option.icon}</span>
                    <span>${escapeHTML(option.text)}</span>
                `;

                menuItem.addEventListener('click', () => {
                    try {
                        option.action();
                    } catch (error) {
                        console.error(`Error executing action for "${option.text}":`, error);
                        showNotification(`Failed to execute "${option.text}".`);
                    }
                    hideContextMenu();
                });

                // Hover-Effekte für bessere UX
                menuItem.addEventListener('mouseover', () => {
                    menuItem.style.backgroundColor = '#f0f0f0';
                });
                menuItem.addEventListener('mouseout', () => {
                    menuItem.style.backgroundColor = 'transparent';
                });

                contextMenu.appendChild(menuItem);
            });

            document.body.appendChild(contextMenu);

            // Kontextmenü öffnen bei Rechtsklick
            let mouseX = 0;
            let mouseY = 0;
            document.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                mouseX = e.clientX;
                mouseY = e.clientY;

                // Position des Kontextmenüs berechnen, um Überlauf zu vermeiden
                const menuWidth = 200; // Geschätzte Breite des Menüs
                const menuHeight = options.length * 40; // Geschätzte Höhe des Menüs
                let posX = e.pageX;
                let posY = e.pageY;

                if (window.innerWidth - e.pageX < menuWidth) {
                    posX = e.pageX - menuWidth;
                }
                if (window.innerHeight - e.pageY < menuHeight) {
                    posY = e.pageY - menuHeight;
                }

                contextMenu.style.left = `${posX}px`;
                contextMenu.style.top = `${posY}px`;
                contextMenu.classList.add('visible');
                overlay.style.display = 'block';
            });

            // Kontextmenü und Overlay schließen
            overlay.addEventListener('click', hideContextMenu);
            document.addEventListener('click', hideContextMenu);
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    hideContextMenu();
                }
            });

            // Funktion zum Verstecken des Kontextmenüs
            function hideContextMenu() {
                contextMenu.classList.remove('visible');
                overlay.style.display = 'none';
            }
        } catch (error) {
            console.error('Error creating custom context menu:', error);
            showNotification('Failed to create context menu.');
        }
    };

    // Funktion zum Kopieren der aktuellen Seiten-URL
    const copyPageURL = () => {
        try {
            navigator.clipboard.writeText(window.location.href)
                .then(() => {
                    showNotification('Page URL copied to clipboard!');
                })
                .catch(err => {
                    console.error('Failed to copy URL: ', err);
                    showNotification('Failed to copy URL.');
                });
        } catch (error) {
            console.error('Error copying URL:', error);
            showNotification('Failed to copy URL.');
        }
    };

    // Funktion zum Öffnen des benutzerdefinierten DevTools
    const openCustomDevTools = () => {
        try {
            const script = document.createElement('script');
            script.src = chrome.runtime.getURL('Devtools.js'); // Annahme: Devtools.js ist Teil der Extension
            script.onload = () => {
                console.log('Devtools.js loaded successfully.');
                showNotification('Custom DevTools opened.');
            };
            script.onerror = () => {
                console.error('Failed to load Devtools.js.');
                showNotification('Failed to open Custom DevTools.');
            };
            document.body.appendChild(script);
        } catch (error) {
            console.error('Error opening Custom DevTools:', error);
            showNotification('Failed to open Custom DevTools.');
        }
    };

    // Funktion zum Anzeigen von Benachrichtigungen
    const showNotification = (message) => {
        try {
            const notification = document.createElement('div');
            notification.classList.add('custom-notification');
            notification.textContent = message;
            document.body.appendChild(notification);

            // Trigger reflow für CSS-Transition
            window.getComputedStyle(notification).opacity;
            notification.classList.add('visible');

            // Nach 3 Sekunden entfernen
            setTimeout(() => {
                notification.classList.remove('visible');
                notification.addEventListener('transitionend', () => {
                    notification.remove();
                });
            }, 3000);
        } catch (error) {
            console.error('Error showing notification:', error);
        }
    };

    // Initial Setup
    const initialize = () => {
        loadResources();
        injectStyles();
        createCustomContextMenu();
    };

    // DOMContentLoaded oder sofort ausführen
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

})();