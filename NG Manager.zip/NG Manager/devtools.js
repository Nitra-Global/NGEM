(function() {
    // Dynamisch Inter-Schriftart und Material Icons laden
    const loadResources = () => {
        const interLink = document.createElement('link');
        interLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap';
        interLink.rel = 'stylesheet';
        document.head.appendChild(interLink);

        const materialIconsLink = document.createElement('link');
        materialIconsLink.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';
        materialIconsLink.rel = 'stylesheet';
        document.head.appendChild(materialIconsLink);
    };

    // Dynamisch CSS-Stile hinzufügen
    const injectStyles = () => {
        const style = document.createElement('style');
        style.textContent = `
            /* DevTools Panel */
            #custom-devtools-panel {
                position: fixed;
                bottom: 0;
                right: 0;
                width: 400px;
                height: 300px;
                background-color: #fff;
                border: 1px solid #ccc;
                border-top-left-radius: 8px;
                box-shadow: 0 -2px 8px rgba(0,0,0,0.2);
                z-index: 10002;
                font-family: 'Inter', sans-serif;
                display: flex;
                flex-direction: column;
                padding: 10px;
                transition: transform 0.3s ease, opacity 0.3s ease;
                opacity: 0;
                transform: translateY(100%);
            }

            #custom-devtools-panel.visible {
                opacity: 1;
                transform: translateY(0);
            }

            /* Header */
            #custom-devtools-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
            }

            #custom-devtools-header h3 {
                margin: 0;
                font-size: 18px;
                color: #333;
            }

            #custom-devtools-close {
                cursor: pointer;
                font-size: 20px;
                color: #888;
            }

            /* Tabs */
            #custom-devtools-tabs {
                display: flex;
                border-bottom: 1px solid #ccc;
                margin-bottom: 10px;
            }

            .custom-tab {
                padding: 8px 16px;
                cursor: pointer;
                transition: background-color 0.2s ease;
                color: #555;
                font-size: 14px;
            }

            .custom-tab.active {
                border-bottom: 2px solid #1a73e8;
                color: #1a73e8;
                font-weight: 600;
            }

            /* Tab Content */
            .custom-tab-content {
                flex: 1;
                overflow-y: auto;
            }

            /* Elements Tab */
            #elements-content .element-info {
                margin-bottom: 10px;
            }

            #elements-content .element-info h4 {
                margin: 0 0 5px 0;
                font-size: 16px;
                color: #333;
            }

            #elements-content .element-info pre {
                background-color: #f5f5f5;
                padding: 8px;
                border-radius: 4px;
                overflow-x: auto;
                font-size: 14px;
                color: #555;
            }

            /* Console Tab */
            #console-content .console-log {
                margin-bottom: 5px;
                font-size: 14px;
                color: #333;
            }

            #console-content .console-log.log {
                color: #1a73e8;
            }

            #console-content .console-log.error {
                color: #dc3545;
            }

            #console-content .console-log.warn {
                color: #fd7e14;
            }

            #console-content .console-log.info {
                color: #17a2b8;
            }

            /* Buttons */
            .custom-button {
                padding: 6px 12px;
                margin-top: 5px;
                border: none;
                border-radius: 4px;
                background-color: #1a73e8;
                color: #fff;
                cursor: pointer;
                font-size: 14px;
                transition: background-color 0.3s ease;
            }

            .custom-button:hover {
                background-color: #1669c1;
            }

            /* Responsive Design */
            @media (max-width: 500px) {
                #custom-devtools-panel {
                    width: 100%;
                    height: 50%;
                    bottom: 0;
                    right: 0;
                    border-radius: 8px 8px 0 0;
                }
            }

            /* Console Scrollbar */
            #console-content::-webkit-scrollbar {
                width: 8px;
            }

            #console-content::-webkit-scrollbar-thumb {
                background-color: rgba(0,0,0,0.2);
                border-radius: 4px;
            }
        `;
        document.head.appendChild(style);
    };

    // Utility Funktion zum Escaping von HTML
    const escapeHTML = (str) => {
        return String(str).replace(/[&<>"'`=\/]/g, function (s) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;',
                '/': '&#x2F;',
                '`': '&#x60;',
                '=': '&#x3D;'
            })[s];
        });
    };

    // Funktion zum Erstellen des DevTools Panels
    const createDevToolsPanel = () => {
        try {
            // Überprüfen, ob das Panel bereits existiert
            if (document.getElementById('custom-devtools-panel')) return;

            // Panel erstellen
            const panel = document.createElement('div');
            panel.id = 'custom-devtools-panel';
            panel.innerHTML = `
                <div id="custom-devtools-header">
                    <h3>Custom DevTools</h3>
                    <span id="custom-devtools-close" class="material-icons">close</span>
                </div>
                <div id="custom-devtools-tabs">
                    <div class="custom-tab active" data-tab="elements">Elements</div>
                    <div class="custom-tab" data-tab="console">Console</div>
                </div>
                <div id="elements-content" class="custom-tab-content">
                    <button id="inspect-element-button" class="custom-button">Inspect Element</button>
                    <div class="element-info" id="selected-element-info">
                        <h4>Selected Element:</h4>
                        <pre id="element-attributes">None</pre>
                    </div>
                </div>
                <div id="console-content" class="custom-tab-content" style="display: none;">
                    <div id="console-logs"></div>
                </div>
            `;
            document.body.appendChild(panel);

            // Header Schließen-Button
            document.getElementById('custom-devtools-close').addEventListener('click', () => {
                panel.classList.remove('visible');
            });

            // Tabs wechseln
            const tabs = document.querySelectorAll('.custom-tab');
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    const tabName = tab.getAttribute('data-tab');
                    document.querySelectorAll('.custom-tab-content').forEach(content => {
                        content.style.display = 'none';
                    });
                    document.getElementById(`${tabName}-content`).style.display = 'block';
                });
            });

            // Inspect Element Funktion
            const inspectButton = document.getElementById('inspect-element-button');
            let isInspecting = false;
            inspectButton.addEventListener('click', () => {
                if (!isInspecting) {
                    isInspecting = true;
                    inspectButton.textContent = 'Click on an element';
                    document.body.style.cursor = 'crosshair';

                    const onMouseOver = (e) => {
                        e.target.style.outline = '2px solid #1a73e8';
                    };

                    const onMouseOut = (e) => {
                        e.target.style.outline = 'none';
                    };

                    const onClick = (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        const element = e.target;
                        displayElementInfo(element);
                        endInspection();
                    };

                    const endInspection = () => {
                        isInspecting = false;
                        inspectButton.textContent = 'Inspect Element';
                        document.body.style.cursor = 'default';
                        document.removeEventListener('mouseover', onMouseOver);
                        document.removeEventListener('mouseout', onMouseOut);
                        document.removeEventListener('click', onClick);
                    };

                    document.addEventListener('mouseover', onMouseOver);
                    document.addEventListener('mouseout', onMouseOut);
                    document.addEventListener('click', onClick);
                }
            });

            // Funktion zur Anzeige der Elementinformationen
            const displayElementInfo = (element) => {
                const attributes = Array.from(element.attributes).map(attr => `${attr.name}="${attr.value}"`).join('\n');
                document.getElementById('element-attributes').textContent = attributes || 'None';
            };

            // Console Logs initialisieren
            initializeConsoleLogs();
        } catch (error) {
            console.error('Error creating DevTools panel:', error);
            showNotification('Failed to create DevTools panel.');
        }
    };

    // Funktion zum Initialisieren der Console Logs
    const initializeConsoleLogs = () => {
        try {
            const consoleLogsContainer = document.getElementById('console-logs');

            // Nachrichten vom Content Script empfangen
            chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
                if (request.type === 'console-log') {
                    const logEntry = document.createElement('div');
                    logEntry.classList.add('console-log', request.level);
                    logEntry.textContent = `[${request.level.toUpperCase()}] ${request.message}`;
                    consoleLogsContainer.appendChild(logEntry);
                    consoleLogsContainer.scrollTop = consoleLogsContainer.scrollHeight;
                }
            });
        } catch (error) {
            console.error('Error initializing console logs:', error);
            showNotification('Failed to initialize Console Viewer.');
        }
    };

    // Funktion zum Anzeigen von Benachrichtigungen
    const showNotification = (message) => {
        try {
            const notification = document.createElement('div');
            notification.classList.add('custom-notification');
            notification.textContent = message;
            document.body.appendChild(notification);

            // Trigger reflow für CSS-Transition
            window.getComputedStyle(notification).opacity;
            notification.classList.add('visible');

            // Nach 3 Sekunden entfernen
            setTimeout(() => {
                notification.classList.remove('visible');
                notification.addEventListener('transitionend', () => {
                    notification.remove();
                });
            }, 3000);
        } catch (error) {
            console.error('Error showing notification:', error);
        }
    };

    // Funktion zum Öffnen von Custom DevTools
    const openCustomDevTools = () => {
        try {
            const panel = document.getElementById('custom-devtools-panel');
            if (panel) {
                panel.classList.add('visible');
            } else {
                createDevToolsPanel();
                setTimeout(() => {
                    const newPanel = document.getElementById('custom-devtools-panel');
                    if (newPanel) newPanel.classList.add('visible');
                }, 10);
            }
        } catch (error) {
            console.error('Error opening Custom DevTools:', error);
            showNotification('Failed to open Custom DevTools.');
        }
    };

    // Initial Setup
    const initialize = () => {
        loadResources();
        injectStyles();
        createDevToolsPanel();
    };

    // DOMContentLoaded oder sofort ausführen
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

    // Funktion zum Öffnen von DevTools über Kontextmenü
    const setupContextMenuListener = () => {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.type === 'open-devtools') {
                openCustomDevTools();
            }
        });
    };

    setupContextMenuListener();

})();
