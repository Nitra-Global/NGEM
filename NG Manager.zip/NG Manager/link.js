(function() {
    // Dynamisch Inter-Schriftart laden
    const loadInterFont = () => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    };

    // Dynamisch CSS-Stile hinzufügen
    const injectStyles = () => {
        const style = document.createElement('style');
        style.textContent = `
            /* Overlay Styles */
            .custom-popup-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(255, 255, 255, 0.8);
                z-index: 9999;
                opacity: 0;
                transition: opacity 0.4s ease;
            }

            .custom-popup-overlay.visible {
                opacity: 1;
            }

            /* Popup Styles */
            .custom-popup-container {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(0.8);
                background-color: #fff;
                border-radius: 12px;
                padding: 20px;
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
                z-index: 10000;
                max-width: 90%;
                width: 400px;
                box-sizing: border-box;
                font-family: 'Inter', sans-serif;
                font-size: 16px;
                transition: transform 0.4s ease, opacity 0.4s ease;
                opacity: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                color: #333;
                word-break: break-word; /* Sicherstellen, dass lange Links umbrechen */
                overflow-wrap: break-word;
            }

            .custom-popup-container.visible {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }

            .custom-popup-header {
                font-size: 22px;
                color: #333;
                margin-bottom: 15px;
                font-weight: 600;
            }

            .custom-popup-message {
                font-size: 16px;
                color: #555;
                margin-bottom: 15px;
            }

            .custom-popup-url {
                font-size: 16px;
                color: #1a73e8;
                margin-bottom: 20px;
                word-break: break-word; /* Sicherstellen, dass lange Links umbrechen */
                overflow-wrap: break-word;
            }

            .custom-popup-warning {
                font-size: 14px;
                color: #dc3545;
                margin-bottom: 20px;
            }

            .custom-popup-buttons {
                display: flex;
                gap: 10px;
                margin-bottom: 20px;
                width: 100%;
                justify-content: center;
            }

            .custom-popup-buttons button {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 16px;
                transition: background-color 0.3s ease;
                flex: 1;
                max-width: 150px;
            }

            .confirm-button {
                background-color: #1a73e8;
                color: #fff;
            }

            .confirm-button:hover {
                background-color: #1669c1;
            }

            .cancel-button {
                background-color: #f0f0f0;
                color: #333;
            }

            .cancel-button:hover {
                background-color: #dcdcdc;
            }

            /* Spinner Styles */
            .custom-spinner-container {
                display: none;
                text-align: center;
                width: 100%;
            }

            .custom-spinner {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                border: 4px solid rgba(0, 0, 0, 0.1);
                border-top: 4px solid #333;
                animation: custom-spin 1s linear infinite;
                margin: 0 auto;
            }

            @keyframes custom-spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }

            .spinner-text {
                font-size: 14px;
                color: #555;
                margin-top: 10px;
            }

            /* Error Popup Styles */
            .custom-error-popup-container {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(0.8);
                background-color: #fff;
                border-radius: 12px;
                padding: 20px;
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
                z-index: 10000;
                max-width: 90%;
                width: 400px;
                box-sizing: border-box;
                font-family: 'Inter', sans-serif;
                font-size: 16px;
                transition: transform 0.4s ease, opacity 0.4s ease;
                opacity: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                color: #333;
                word-break: break-word; /* Sicherstellen, dass lange Nachrichten umbrechen */
                overflow-wrap: break-word;
            }

            .custom-error-popup-container.visible {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }

            .custom-error-header {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 15px;
            }

            .custom-error-header .custom-material-icons {
                font-size: 24px;
                color: #dc3545;
                margin-right: 10px;
            }

            .custom-error-header h1 {
                font-size: 22px;
                color: #333;
                margin: 0;
            }

            .custom-error-message {
                font-size: 16px;
                color: #555;
                margin-bottom: 20px;
            }

            .custom-error-close-button {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                background-color: #dc3545;
                color: #fff;
                cursor: pointer;
                font-size: 16px;
                transition: background-color 0.3s ease;
            }

            .custom-error-close-button:hover {
                background-color: #c82333;
            }

            /* Responsive Design */
            @media (max-width: 500px) {
                .custom-popup-container, .custom-error-popup-container {
                    width: 90%;
                }

                .custom-popup-buttons button {
                    flex: none;
                    width: 100%;
                    max-width: none;
                }
            }

            /* Material Icons */
            .custom-material-icons {
                font-family: 'Material Icons';
                font-weight: normal;
                font-style: normal;
                font-size: 24px;
                line-height: 1;
                letter-spacing: normal;
                text-transform: none;
                display: inline-block;
                white-space: nowrap;
                word-wrap: normal;
                direction: ltr;
                -webkit-font-feature-settings: 'liga';
                -webkit-font-smoothing: antialiased;
            }
        `;
        document.head.appendChild(style);

        // Material Icons
        const materialIconsLink = document.createElement('link');
        materialIconsLink.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';
        materialIconsLink.rel = 'stylesheet';
        document.head.appendChild(materialIconsLink);
    };

    // Utility function to escape HTML to prevent XSS
    const escapeHTML = (str) => {
        return String(str).replace(/[&<>"'`=\/]/g, function (s) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;',
                '/': '&#x2F;',
                '`': '&#x60;',
                '=': '&#x3D;'
            })[s];
        });
    };

    // Create Overlay
    const createOverlay = () => {
        const overlay = document.createElement('div');
        overlay.classList.add('custom-popup-overlay');
        return overlay;
    };

    // Create Popup
    const createPopup = (url) => {
        const isHttps = url.startsWith('https://');
        const linkColor = isHttps ? '#1a73e8' : '#dc3545';

        const popup = document.createElement('div');
        popup.classList.add('custom-popup-container');

        popup.innerHTML = `
            <div class="custom-popup-header">Leaving NG Extension Manager</div>
            <div class="custom-popup-message">You are about to navigate away from the NG Extension Manager. Do you wish to continue?</div>
            <div class="custom-popup-url">${escapeHTML(url)}</div>
            ${!isHttps ? '<div class="custom-popup-warning">Warning: This link is not secure (no HTTPS). Proceed with caution.</div>' : ''}
            <div class="custom-popup-buttons">
                <button id="confirm-leave" class="confirm-button">Yes, Continue</button>
                <button id="cancel-leave" class="cancel-button">No, Cancel</button>
            </div>
            <div class="custom-spinner-container" id="spinner-container">
                <div class="custom-spinner"></div>
                <div class="spinner-text">Redirecting, please wait...</div>
            </div>
        `;

        return popup;
    };

    // Create Error Popup
    const createErrorPopup = (message) => {
        const errorPopup = document.createElement('div');
        errorPopup.classList.add('custom-error-popup-container');

        errorPopup.innerHTML = `
            <div class="custom-error-header">
                <span class="custom-material-icons">error</span>
                <h1>Error</h1>
            </div>
            <div class="custom-error-message">${escapeHTML(message)}</div>
            <button id="error-close" class="custom-error-close-button">Close</button>
        `;

        return errorPopup;
    };

    // Show Popup
    const showPopup = (url) => {
        try {
            const overlay = createOverlay();
            const popup = createPopup(url);

            document.body.appendChild(overlay);
            document.body.appendChild(popup);

            // Trigger reflow to enable transition
            window.getComputedStyle(overlay).opacity;
            window.getComputedStyle(popup).opacity;

            overlay.classList.add('visible');
            popup.classList.add('visible');

            const confirmButton = popup.querySelector('#confirm-leave');
            const cancelButton = popup.querySelector('#cancel-leave');

            confirmButton.addEventListener('click', () => {
                confirmButton.disabled = true;
                cancelButton.disabled = true;
                showSpinner(popup);
                setTimeout(() => {
                    try {
                        window.open(url, '_blank');
                        closePopup(popup, overlay);
                    } catch (error) {
                        console.error('Error opening URL:', error);
                        closePopup(popup, overlay);
                        showErrorPopup('An error occurred while trying to open the URL.');
                    }
                }, 1300);
            });

            cancelButton.addEventListener('click', () => closePopup(popup, overlay));

            const escapeListener = (event) => {
                if (event.key === 'Escape') closePopup(popup, overlay);
            };
            document.addEventListener('keydown', escapeListener);

            // Cleanup event listener when popup is closed
            popup.addEventListener('transitionend', () => {
                if (!popup.classList.contains('visible')) {
                    document.removeEventListener('keydown', escapeListener);
                }
            });
        } catch (error) {
            console.error('Error showing popup:', error);
            showErrorPopup('Failed to display the popup.');
        }
    };

    // Show Spinner
    const showSpinner = (popup) => {
        try {
            const spinnerContainer = popup.querySelector('#spinner-container');
            if (spinnerContainer) {
                spinnerContainer.style.display = 'block';
            }
        } catch (error) {
            console.error('Error showing spinner:', error);
        }
    };

    // Close Popup
    const closePopup = (popup, overlay) => {
        try {
            popup.classList.remove('visible');
            overlay.classList.remove('visible');

            // Wait for transition to end before removing elements
            popup.addEventListener('transitionend', () => {
                if (popup.parentElement) popup.remove();
            }, { once: true });

            overlay.addEventListener('transitionend', () => {
                if (overlay.parentElement) overlay.remove();
            }, { once: true });
        } catch (error) {
            console.error('Error closing popup:', error);
        }
    };

    // Show Error Popup
    const showErrorPopup = (message) => {
        try {
            const overlay = createOverlay();
            const errorPopup = createErrorPopup(message);

            document.body.appendChild(overlay);
            document.body.appendChild(errorPopup);

            // Trigger reflow to enable transition
            window.getComputedStyle(overlay).opacity;
            window.getComputedStyle(errorPopup).opacity;

            overlay.classList.add('visible');
            errorPopup.classList.add('visible');

            const closeButton = errorPopup.querySelector('#error-close');

            closeButton.addEventListener('click', () => closePopup(errorPopup, overlay));

            const escapeListener = (event) => {
                if (event.key === 'Escape') closePopup(errorPopup, overlay);
            };
            document.addEventListener('keydown', escapeListener);

            // Cleanup event listener when popup is closed
            errorPopup.addEventListener('transitionend', () => {
                if (!errorPopup.classList.contains('visible')) {
                    document.removeEventListener('keydown', escapeListener);
                }
            });
        } catch (error) {
            console.error('Error showing error popup:', error);
            alert('An unexpected error occurred.');
        }
    };

    // Sanitize URL
    const sanitizeURL = (url) => {
        try {
            const decodedURL = decodeURI(url);
            const sanitizedURL = encodeURI(decodedURL);
            return sanitizedURL;
        } catch (e) {
            console.warn('URL sanitization failed:', e);
            return '';
        }
    };

    // Check if URL is safe
    const isSafeURL = (url) => {
        const unsafeProtocols = /^(chrome|chrome-extension|chrome-devtools|about|javascript|data|file|ftp|mailto|view-source|ws|wss|smb|sftp|telnet|gopher|nntp|news|irc|ircs):/i;
        return !unsafeProtocols.test(url);
    };

    // Event Listener für DOMContentLoaded
    const initialize = () => {
        loadInterFont();
        injectStyles();

        document.body.addEventListener('click', (event) => {
            try {
                const link = event.target.closest('a');
                if (link && link.href && link.hostname !== window.location.hostname) {
                    event.preventDefault();
                    const sanitizedUrl = sanitizeURL(link.href);
                    if (isSafeURL(sanitizedUrl)) {
                        showPopup(sanitizedUrl);
                    } else {
                        showErrorPopup('The URL you are trying to access is not allowed.');
                    }
                }
            } catch (error) {
                console.error('Error handling link click:', error);
                showErrorPopup('An unexpected error occurred.');
            }
        });
    };

    // Initialisierung beim Laden des DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
})();