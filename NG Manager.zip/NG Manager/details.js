// Function to display extension details
function showExtensionDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const extensionId = urlParams.get('id');
    const currentExtensionId = 'ninhjdeipacebhgbhblhjglnaajfehio'; // Current extension manager's ID

    if (!extensionId) {
        showError('No extension ID was provided in the URL. Please ensure the URL contains a valid extension ID.');
        return;
    }

    chrome.management.get(extensionId, function(extension) {
        var extensionDetails = document.getElementById('extension-details');
        extensionDetails.innerHTML = '';

        if (chrome.runtime.lastError) {
            showError('An error occurred while retrieving extension details. Error: ' + chrome.runtime.lastError.message);
            return;
        }

        if (!extension) {
            showError('No extension found with the provided ID. The extension might be uninstalled or the ID may be incorrect.');
            return;
        }

        // Banner for the current extension manager
        if (extension.id === currentExtensionId) {
            var banner = document.createElement('div');
            banner.style.backgroundColor = '#007BFF'; // Blue banner
            banner.style.color = '#fff';
            banner.style.borderRadius = '18px';
            banner.style.padding = '10px';
            banner.style.textAlign = 'center';
            banner.style.fontWeight = 'bold';
            banner.textContent = 'This is the current Extension Manager and cannot be disabled or uninstalled.';
            extensionDetails.appendChild(banner);
        }

        var title = document.createElement('h2');
        title.textContent = extension.name;
        title.className = 'gradient-text';
        extensionDetails.appendChild(title);

        var version = document.createElement('p');
        version.innerHTML = '<i class="material-icons">info</i> Version: ' + extension.version + ' (ID: ' + extension.id + ')';
        if (extension.manifestVersion) {
            version.innerHTML += ' - Manifest v' + extension.manifestVersion;
        }
        extensionDetails.appendChild(version);

        var description = document.createElement('p');
        description.innerHTML = '<i class="material-icons">description</i> Description: ' + extension.description;
        extensionDetails.appendChild(description);

        if (extension.creator) {
            var creator = document.createElement('p');
            creator.innerHTML = '<i class="material-icons">person</i> Creator: ' + extension.creator;
            extensionDetails.appendChild(creator);
        }

        if (extension.homepageUrl) {
            var homepageLink = document.createElement('p');
            homepageLink.innerHTML = '<i class="material-icons">link</i> Homepage: <a href="' + extension.homepageUrl + '" target="_blank">' + extension.homepageUrl + '</a>';
            extensionDetails.appendChild(homepageLink);
        }

        if (extension.optionsUrl) {
            var optionsLink = document.createElement('p');
            optionsLink.innerHTML = '<i class="material-icons">settings</i> Options: <a href="' + extension.optionsUrl + '" target="_blank">Open Options</a>';
            extensionDetails.appendChild(optionsLink);
        }

        var enabledStatus = document.createElement('p');
        enabledStatus.id = 'enabled-status';
        enabledStatus.innerHTML = '<i class="material-icons">power_settings_new</i> Status: ' + (extension.enabled ? 'Enabled' : 'Disabled');
        extensionDetails.appendChild(enabledStatus);

        // Disable the buttons if this is the current extension manager
        if (extension.id === currentExtensionId) {
            var message = document.createElement('p');
            message.textContent = 'Please uninstall or disable this extension in the Chrome Extension Manager.';
            message.style.color = '#666'; // Grey color for emphasis
            extensionDetails.appendChild(message);
        } else {
            var enableDisableButton = document.createElement('button');
            enableDisableButton.id = 'enable-disable-btn';
            enableDisableButton.textContent = extension.enabled ? 'Disable' : 'Enable';
            enableDisableButton.addEventListener('click', function() {
                toggleExtensionStatus(extensionId, !extension.enabled);
            });
            extensionDetails.appendChild(enableDisableButton);

            var uninstallButton = document.createElement('button');
            uninstallButton.id = 'uninstall-btn';
            uninstallButton.textContent = 'Uninstall';
            uninstallButton.addEventListener('click', function() {
                uninstallExtension(extensionId);
            });
            extensionDetails.appendChild(uninstallButton);
        }

        // Create the permissions section
        var permissionsBox = document.createElement('div');
        permissionsBox.classList.add('permissions-box');

        var header = document.createElement('h3');
        header.innerHTML = '<i class="material-icons">security</i> Permissions:';
        permissionsBox.appendChild(header);

        var permissionGroups = {
            "Browser & Data Access": [
                "activeTab", "contextMenus", "tabs", "webNavigation", "webRequest", "webRequestBlocking", "notifications",
                "browsingData", "bookmarks", "clipboardRead", "clipboardWrite", "downloads", "storage", "sessions",
                "topSites", "tabCapture", "contentSettings"
            ],
            "Extension & System Management": [
                "management", "history", "power", "idle", "system.cpu", "system.memory", "system.storage"
            ],
            "Networking & Communication": [
                "dns", "udp-send", "udp-receive", "tcp-connect", "proxy", "runtime", "alarms", "nativeMessaging", "gcm",
                "webSocket", "networking.onc"
            ],
            "Privacy & Scripting": [
                "geolocation", "identity", "privacy", "scripting", "declarativeContent", "tabs.executeScript", "tabs.insertCSS",
                "contentSettings"
            ],
            "Experimental & Debugging": [
                "experimental", "debugger"
            ],
            "Browsing & File System": [
                "topSites", "tabCapture", "webRequestBlocking", "fileSystem", "unlimitedStorage", "storage"
            ],
            "Media": [
                "videoCapture", "audioCapture"
            ],
            "Accessibility": [
                "accessibilityFeatures.read", "accessibilityFeatures.modify"
            ],
            "Hardware": [
                "hid", "serial", "usb", "bluetooth", "bluetoothDevices"
            ],
            "Device & Display": [
                "displaySource"
            ]
        };

        var extensionPermissions = extension.permissions || [];

        var permissionsFound = false;

        for (var groupName in permissionGroups) {
            var groupPermissions = permissionGroups[groupName];
            var groupContainer = document.createElement('div');
            groupContainer.classList.add('permission-group');

            var groupHeader = document.createElement('div');
            groupHeader.classList.add('permission-group-header');
            var groupTitle = document.createElement('h4');
            groupTitle.textContent = `${groupName} (${groupPermissions.filter(p => extensionPermissions.includes(p)).length})`;
            groupHeader.appendChild(groupTitle);

            var expandIcon = document.createElement('i');
            expandIcon.classList.add('material-icons');
            expandIcon.textContent = 'expand_more';
            groupHeader.appendChild(expandIcon);
            groupContainer.appendChild(groupHeader);

            var groupList = document.createElement('ul');
            groupList.classList.add('permission-list');
            groupPermissions.forEach(function(permissionName) {
                if (extensionPermissions.includes(permissionName)) {
                    var permissionItem = document.createElement('li');
                    permissionItem.textContent = permissionName;
                    groupList.appendChild(permissionItem);
                    permissionsFound = true;
                }
            });
            if (groupList.childElementCount > 0) {
                groupContainer.appendChild(groupList);
                permissionsBox.appendChild(groupContainer);
            }
        }

        if (!permissionsFound) {
            var noPermissionsMessage = document.createElement('p');
            noPermissionsMessage.classList.add('info-message');
            noPermissionsMessage.innerHTML = '<i class="material-icons">info</i> No permissions found for this extension. It may have no active permissions or there could be an issue with the permissions data.';
            permissionsBox.appendChild(noPermissionsMessage);
        }

        extensionDetails.appendChild(permissionsBox);

        // Create the notes section
        var notesSection = document.createElement('div');
        notesSection.id = 'notes-section';
        var notesTitle = document.createElement('h3');
        notesTitle.textContent = 'Notes';
        notesSection.appendChild(notesTitle);

        var notesInput = document.createElement('textarea');
notesInput.id = 'notes-input';
notesInput.rows = 4;
notesInput.placeholder = 'Add your notes here...';
notesInput.maxLength = 220; // Setze hier das gewünschte Limit in Zeichen
notesSection.appendChild(notesInput);

        var addButton = document.createElement('button');
        addButton.textContent = 'Add Note';
        addButton.addEventListener('click', function() {
            addNote(extensionId, notesInput.value);
            notesInput.value = '';
        });
        notesSection.appendChild(addButton);

        var notesDisplay = document.createElement('div');
        notesDisplay.id = 'notes-display';
        notesSection.appendChild(notesDisplay);

        extensionDetails.appendChild(notesSection);

        // Load existing notes
        loadNotes(extensionId);

        document.querySelectorAll('.permission-group-header').forEach(header => {
            header.addEventListener('click', function() {
                var groupList = this.nextElementSibling;
                var isVisible = groupList.style.display === 'block';
                groupList.style.display = isVisible ? 'none' : 'block';
                this.querySelector('.material-icons').textContent = isVisible ? 'expand_more' : 'expand_less';
            });

            var groupList = header.nextElementSibling;
            groupList.style.display = 'block';
            header.querySelector('.material-icons').textContent = 'expand_less';
        });
    });
}

// Function to add a new note with validation and feedback
function addNote(extensionId, note) {
    let notes = JSON.parse(localStorage.getItem('notes_' + extensionId) || '[]');

    // Überprüfen, ob die Notiz leer ist
    if (!note.trim()) {
        showMessage('Cannot add an empty note!', 'error');
        return;
    }

    // Zeichenlimit überprüfen (z.B. 500 Zeichen)
    if (note.length > 500) {
        showMessage('Note is too long! Maximum 500 characters allowed.', 'error');
        return;
    }

    // Notiz hinzufügen und speichern
    notes.push(note);
    localStorage.setItem('notes_' + extensionId, JSON.stringify(notes));
    loadNotes(extensionId);
}

// Function to load notes from local storage
function loadNotes(extensionId) {
    var notes = JSON.parse(localStorage.getItem('notes_' + extensionId) || '[]');
    var notesDisplay = document.getElementById('notes-display');
    notesDisplay.innerHTML = '';

    if (notes.length === 0) {
        notesDisplay.innerHTML = '<p>You have not saved any notes for this extension</p>';
        return;
    }

    notes.forEach((note, index) => {
        var noteDiv = document.createElement('div');
        noteDiv.className = 'note-item';

        var noteText = document.createElement('p');
        var maxChars = 100; // Maximum Anzahl von Zeichen, die angezeigt werden sollen

        // Wenn die Notiz länger als maxChars ist, kürzen und "more..." hinzufügen
        if (note.length > maxChars) {
            noteText.textContent = note.substring(0, maxChars) + '... ';
            
            var moreLink = document.createElement('a');
            moreLink.href = '#';
            moreLink.textContent = 'more';
            moreLink.addEventListener('click', function(e) {
                e.preventDefault();
                noteText.textContent = note; // Vollständige Notiz anzeigen
            });

            noteText.appendChild(moreLink);
        } else {
            noteText.textContent = note; // Notiz ist kurz genug, vollständig anzeigen
        }

        noteDiv.appendChild(noteText);

        var deleteButton = document.createElement('button');
        deleteButton.className = 'delete-note-btn';
        deleteButton.innerHTML = '<i class="material-icons">delete</i>';
        deleteButton.addEventListener('click', function() {
            deleteNote(extensionId, index);
        });
        noteDiv.appendChild(deleteButton);

        notesDisplay.appendChild(noteDiv);
    });
}

// Function to delete a note
function deleteNote(extensionId, noteIndex) {
    let notes = JSON.parse(localStorage.getItem('notes_' + extensionId) || '[]');
    notes.splice(noteIndex, 1);
    localStorage.setItem('notes_' + extensionId, JSON.stringify(notes));
    loadNotes(extensionId);
}

// Function to toggle extension status (enable/disable)
function toggleExtensionStatus(extensionId, enable) {
    chrome.management.setEnabled(extensionId, enable, function() {
        if (chrome.runtime.lastError) {
            showError('An error occurred while toggling extension status. Error: ' + chrome.runtime.lastError.message);
            return;
        }

        // Update status display and button text
        var statusElement = document.getElementById('enabled-status');
        var buttonElement = document.getElementById('enable-disable-btn');
        statusElement.innerHTML = '<i class="material-icons">power_settings_new</i> Status: ' + (enable ? 'Enabled' : 'Disabled');
        buttonElement.textContent = enable ? 'Disable' : 'Enable';
    });
}

// Function to uninstall the extension
function uninstallExtension(extensionId) {
    chrome.management.uninstall(extensionId, function() {
        if (chrome.runtime.lastError) {
            showError('An error occurred while uninstalling the extension. Error: ' + chrome.runtime.lastError.message);
            return;
        }

        // Inform user of successful uninstallation
        showError('Extension has been successfully uninstalled.');
        document.getElementById('extension-details').innerHTML = '';
    });
}

// Function to display an error message with detailed information
function showError(message) {
    var extensionDetails = document.getElementById('extension-details');
    extensionDetails.innerHTML = '<p><i class="material-icons">error</i> ' + message + '</p>';
}

document.addEventListener('DOMContentLoaded', function() {
    showExtensionDetails();
});